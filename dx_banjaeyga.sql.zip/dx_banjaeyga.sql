-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 09, 2017 at 04:12 PM
-- Server version: 5.5.57-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dx_banjaeyga`
--

-- --------------------------------------------------------

--
-- Table structure for table `architects`
--

CREATE TABLE IF NOT EXISTS `architects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user_id`),
  KEY `fk_architects_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `architects`
--

INSERT INTO `architects` (`id`, `user_id`) VALUES
(1, 38),
(2, 39),
(3, 40),
(4, 52);

-- --------------------------------------------------------

--
-- Table structure for table `architect_trusted_vendors`
--

CREATE TABLE IF NOT EXISTS `architect_trusted_vendors` (
  `id` int(11) NOT NULL,
  `vendors_id` int(11) NOT NULL,
  `architects_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`vendors_id`,`architects_id`),
  KEY `fk_architect_vendors_vendors1` (`vendors_id`),
  KEY `fk_architect_vendors_products1` (`architects_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `architect_trusted_vendors`
--

INSERT INTO `architect_trusted_vendors` (`id`, `vendors_id`, `architects_id`) VALUES
(1, 1, 1),
(2, 19, 1),
(6, 19, 4),
(7, 23, 4),
(8, 24, 4),
(3, 25, 1),
(9, 25, 4),
(4, 27, 1),
(5, 28, 1);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `image`, `date_created`) VALUES
(1, 'Rafaqat Tiles', '14967536335936a5e1e43b94.25109772.png', '2017-06-06 12:53:53'),
(3, 'xyz', '14967536145936a5cec88ba8.40741164.png', '2017-06-06 12:53:34'),
(4, 'SMEG', '14967537995936a687c89b40.19083354.png', '2017-06-06 12:56:39'),
(5, 'SMEG', '14967536575936a5f960f062.21708492.png', '2017-06-06 12:54:17'),
(6, 'Opel', '14967536765936a60cbf3b08.10993348.png', '2017-06-06 12:54:36'),
(7, 'Alf Group Italia', '14967536965936a6209dbfa8.74487254.png', '2017-06-06 12:54:56');

-- --------------------------------------------------------

--
-- Table structure for table `builders`
--

CREATE TABLE IF NOT EXISTS `builders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user_id`),
  KEY `fk_builders_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `builders`
--

INSERT INTO `builders` (`id`, `user_id`) VALUES
(4, 11),
(5, 16),
(6, 28),
(7, 29),
(8, 30),
(9, 31),
(10, 37);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `parent` int(10) NOT NULL DEFAULT '0',
  `sub_parent` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `description`, `date_created`, `status`, `parent`, `sub_parent`) VALUES
(4, 'Flooring', 'Flooring being sold by different vendors.', '2017-05-08 13:08:16', '1', 0, 0),
(5, 'Kitchens', 'Kitchens category description', '2017-05-09 06:14:30', '1', 0, 0),
(6, 'Bathrooms', 'Bathrooms category description', '2017-05-09 06:14:55', '1', 0, 0),
(7, 'Bathroom Tiles', 'Tiles used in Batroom are included here.', '2017-05-10 09:20:34', '1', 6, 0),
(8, 'bathroom pipes', 'Pipes used in bathroom are included here.', '2017-05-10 09:21:22', '1', 6, 0),
(9, 'Kitchen washers', 'Kitchen Washers are included.', '2017-05-10 09:22:47', '1', 5, 0),
(10, 'wall tiles', '', '2017-05-10 12:48:38', '1', 4, 0),
(12, 'wall tiles', '', '2017-05-15 13:02:19', '1', 6, 0),
(13, 'Sink', 'kitchens sinks listed here.', '2017-05-19 07:24:37', '1', 5, 9),
(14, 'Faucets', 'kitchens Faucets listed here.', '2017-05-19 07:25:52', '1', 5, 9),
(15, 'Furniture & Decor', 'Furniture Description', '2017-05-30 12:01:47', '1', 0, 0),
(16, 'Construction Materials', 'Con Description', '2017-05-30 12:02:30', '1', 0, 0),
(17, 'Bedrooms', '', '2017-05-30 12:03:15', '1', 15, 0),
(18, 'Beds', '', '2017-05-30 12:03:39', '1', 15, 17),
(19, 'Home Automation', '', '2017-06-19 15:37:02', '1', 0, 0),
(20, 'Lighting Solutions', '', '2017-06-19 15:38:24', '1', 0, 0),
(21, 'Building Systems', '', '2017-06-19 15:38:47', '1', 0, 0),
(22, 'Doors & Wardrobes', '', '2017-06-19 15:40:26', '', 0, 0),
(23, 'Interior Finishes', '', '2017-06-19 15:43:24', '1', 0, 0),
(24, 'Wall cladding', '', '2017-06-20 06:26:18', '1', 23, 0),
(25, 'External Works', '', '2017-06-20 10:17:44', '1', 0, 0),
(26, 'Coatings', '', '2017-06-20 12:39:00', '1', 23, 0);

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

CREATE TABLE IF NOT EXISTS `configurations` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `value` varchar(45) DEFAULT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `configurations`
--

INSERT INTO `configurations` (`id`, `name`, `value`, `date_created`, `status`) VALUES
(1, 'confname', 'confvalue', '33', '33'),
(2, 'confname2', 'confvalue2', '12-12-2017', '11');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=246 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES
(1, 'AF', 'Afghanistan'),
(2, 'AL', 'Albania'),
(3, 'DZ', 'Algeria'),
(4, 'DS', 'American Samoa'),
(5, 'AD', 'Andorra'),
(6, 'AO', 'Angola'),
(7, 'AI', 'Anguilla'),
(8, 'AQ', 'Antarctica'),
(9, 'AG', 'Antigua and Barbuda'),
(10, 'AR', 'Argentina'),
(11, 'AM', 'Armenia'),
(12, 'AW', 'Aruba'),
(13, 'AU', 'Australia'),
(14, 'AT', 'Austria'),
(15, 'AZ', 'Azerbaijan'),
(16, 'BS', 'Bahamas'),
(17, 'BH', 'Bahrain'),
(18, 'BD', 'Bangladesh'),
(19, 'BB', 'Barbados'),
(20, 'BY', 'Belarus'),
(21, 'BE', 'Belgium'),
(22, 'BZ', 'Belize'),
(23, 'BJ', 'Benin'),
(24, 'BM', 'Bermuda'),
(25, 'BT', 'Bhutan'),
(26, 'BO', 'Bolivia'),
(27, 'BA', 'Bosnia and Herzegovina'),
(28, 'BW', 'Botswana'),
(29, 'BV', 'Bouvet Island'),
(30, 'BR', 'Brazil'),
(31, 'IO', 'British Indian Ocean Territory'),
(32, 'BN', 'Brunei Darussalam'),
(33, 'BG', 'Bulgaria'),
(34, 'BF', 'Burkina Faso'),
(35, 'BI', 'Burundi'),
(36, 'KH', 'Cambodia'),
(37, 'CM', 'Cameroon'),
(38, 'CA', 'Canada'),
(39, 'CV', 'Cape Verde'),
(40, 'KY', 'Cayman Islands'),
(41, 'CF', 'Central African Republic'),
(42, 'TD', 'Chad'),
(43, 'CL', 'Chile'),
(44, 'CN', 'China'),
(45, 'CX', 'Christmas Island'),
(46, 'CC', 'Cocos (Keeling) Islands'),
(47, 'CO', 'Colombia'),
(48, 'KM', 'Comoros'),
(49, 'CG', 'Congo'),
(50, 'CK', 'Cook Islands'),
(51, 'CR', 'Costa Rica'),
(52, 'HR', 'Croatia (Hrvatska)'),
(53, 'CU', 'Cuba'),
(54, 'CY', 'Cyprus'),
(55, 'CZ', 'Czech Republic'),
(56, 'DK', 'Denmark'),
(57, 'DJ', 'Djibouti'),
(58, 'DM', 'Dominica'),
(59, 'DO', 'Dominican Republic'),
(60, 'TP', 'East Timor'),
(61, 'EC', 'Ecuador'),
(62, 'EG', 'Egypt'),
(63, 'SV', 'El Salvador'),
(64, 'GQ', 'Equatorial Guinea'),
(65, 'ER', 'Eritrea'),
(66, 'EE', 'Estonia'),
(67, 'ET', 'Ethiopia'),
(68, 'FK', 'Falkland Islands (Malvinas)'),
(69, 'FO', 'Faroe Islands'),
(70, 'FJ', 'Fiji'),
(71, 'FI', 'Finland'),
(72, 'FR', 'France'),
(73, 'FX', 'France, Metropolitan'),
(74, 'GF', 'French Guiana'),
(75, 'PF', 'French Polynesia'),
(76, 'TF', 'French Southern Territories'),
(77, 'GA', 'Gabon'),
(78, 'GM', 'Gambia'),
(79, 'GE', 'Georgia'),
(80, 'DE', 'Germany'),
(81, 'GH', 'Ghana'),
(82, 'GI', 'Gibraltar'),
(83, 'GK', 'Guernsey'),
(84, 'GR', 'Greece'),
(85, 'GL', 'Greenland'),
(86, 'GD', 'Grenada'),
(87, 'GP', 'Guadeloupe'),
(88, 'GU', 'Guam'),
(89, 'GT', 'Guatemala'),
(90, 'GN', 'Guinea'),
(91, 'GW', 'Guinea-Bissau'),
(92, 'GY', 'Guyana'),
(93, 'HT', 'Haiti'),
(94, 'HM', 'Heard and Mc Donald Islands'),
(95, 'HN', 'Honduras'),
(96, 'HK', 'Hong Kong'),
(97, 'HU', 'Hungary'),
(98, 'IS', 'Iceland'),
(99, 'IN', 'India'),
(100, 'IM', 'Isle of Man'),
(101, 'ID', 'Indonesia'),
(102, 'IR', 'Iran (Islamic Republic of)'),
(103, 'IQ', 'Iraq'),
(104, 'IE', 'Ireland'),
(105, 'IL', 'Israel'),
(106, 'IT', 'Italy'),
(107, 'CI', 'Ivory Coast'),
(108, 'JE', 'Jersey'),
(109, 'JM', 'Jamaica'),
(110, 'JP', 'Japan'),
(111, 'JO', 'Jordan'),
(112, 'KZ', 'Kazakhstan'),
(113, 'KE', 'Kenya'),
(114, 'KI', 'Kiribati'),
(115, 'KP', 'Korea, Democratic People''s Republic of'),
(116, 'KR', 'Korea, Republic of'),
(117, 'XK', 'Kosovo'),
(118, 'KW', 'Kuwait'),
(119, 'KG', 'Kyrgyzstan'),
(120, 'LA', 'Lao People''s Democratic Republic'),
(121, 'LV', 'Latvia'),
(122, 'LB', 'Lebanon'),
(123, 'LS', 'Lesotho'),
(124, 'LR', 'Liberia'),
(125, 'LY', 'Libyan Arab Jamahiriya'),
(126, 'LI', 'Liechtenstein'),
(127, 'LT', 'Lithuania'),
(128, 'LU', 'Luxembourg'),
(129, 'MO', 'Macau'),
(130, 'MK', 'Macedonia'),
(131, 'MG', 'Madagascar'),
(132, 'MW', 'Malawi'),
(133, 'MY', 'Malaysia'),
(134, 'MV', 'Maldives'),
(135, 'ML', 'Mali'),
(136, 'MT', 'Malta'),
(137, 'MH', 'Marshall Islands'),
(138, 'MQ', 'Martinique'),
(139, 'MR', 'Mauritania'),
(140, 'MU', 'Mauritius'),
(141, 'TY', 'Mayotte'),
(142, 'MX', 'Mexico'),
(143, 'FM', 'Micronesia, Federated States of'),
(144, 'MD', 'Moldova, Republic of'),
(145, 'MC', 'Monaco'),
(146, 'MN', 'Mongolia'),
(147, 'ME', 'Montenegro'),
(148, 'MS', 'Montserrat'),
(149, 'MA', 'Morocco'),
(150, 'MZ', 'Mozambique'),
(151, 'MM', 'Myanmar'),
(152, 'NA', 'Namibia'),
(153, 'NR', 'Nauru'),
(154, 'NP', 'Nepal'),
(155, 'NL', 'Netherlands'),
(156, 'AN', 'Netherlands Antilles'),
(157, 'NC', 'New Caledonia'),
(158, 'NZ', 'New Zealand'),
(159, 'NI', 'Nicaragua'),
(160, 'NE', 'Niger'),
(161, 'NG', 'Nigeria'),
(162, 'NU', 'Niue'),
(163, 'NF', 'Norfolk Island'),
(164, 'MP', 'Northern Mariana Islands'),
(165, 'NO', 'Norway'),
(166, 'OM', 'Oman'),
(167, 'PK', 'Pakistan'),
(168, 'PW', 'Palau'),
(169, 'PS', 'Palestine'),
(170, 'PA', 'Panama'),
(171, 'PG', 'Papua New Guinea'),
(172, 'PY', 'Paraguay'),
(173, 'PE', 'Peru'),
(174, 'PH', 'Philippines'),
(175, 'PN', 'Pitcairn'),
(176, 'PL', 'Poland'),
(177, 'PT', 'Portugal'),
(178, 'PR', 'Puerto Rico'),
(179, 'QA', 'Qatar'),
(180, 'RE', 'Reunion'),
(181, 'RO', 'Romania'),
(182, 'RU', 'Russian Federation'),
(183, 'RW', 'Rwanda'),
(184, 'KN', 'Saint Kitts and Nevis'),
(185, 'LC', 'Saint Lucia'),
(186, 'VC', 'Saint Vincent and the Grenadines'),
(187, 'WS', 'Samoa'),
(188, 'SM', 'San Marino'),
(189, 'ST', 'Sao Tome and Principe'),
(190, 'SA', 'Saudi Arabia'),
(191, 'SN', 'Senegal'),
(192, 'RS', 'Serbia'),
(193, 'SC', 'Seychelles'),
(194, 'SL', 'Sierra Leone'),
(195, 'SG', 'Singapore'),
(196, 'SK', 'Slovakia'),
(197, 'SI', 'Slovenia'),
(198, 'SB', 'Solomon Islands'),
(199, 'SO', 'Somalia'),
(200, 'ZA', 'South Africa'),
(201, 'GS', 'South Georgia South Sandwich Islands'),
(202, 'ES', 'Spain'),
(203, 'LK', 'Sri Lanka'),
(204, 'SH', 'St. Helena'),
(205, 'PM', 'St. Pierre and Miquelon'),
(206, 'SD', 'Sudan'),
(207, 'SR', 'Suriname'),
(208, 'SJ', 'Svalbard and Jan Mayen Islands'),
(209, 'SZ', 'Swaziland'),
(210, 'SE', 'Sweden'),
(211, 'CH', 'Switzerland'),
(212, 'SY', 'Syrian Arab Republic'),
(213, 'TW', 'Taiwan'),
(214, 'TJ', 'Tajikistan'),
(215, 'TZ', 'Tanzania, United Republic of'),
(216, 'TH', 'Thailand'),
(217, 'TG', 'Togo'),
(218, 'TK', 'Tokelau'),
(219, 'TO', 'Tonga'),
(220, 'TT', 'Trinidad and Tobago'),
(221, 'TN', 'Tunisia'),
(222, 'TR', 'Turkey'),
(223, 'TM', 'Turkmenistan'),
(224, 'TC', 'Turks and Caicos Islands'),
(225, 'TV', 'Tuvalu'),
(226, 'UG', 'Uganda'),
(227, 'UA', 'Ukraine'),
(228, 'AE', 'United Arab Emirates'),
(229, 'GB', 'United Kingdom'),
(230, 'US', 'United States'),
(231, 'UM', 'United States minor outlying islands'),
(232, 'UY', 'Uruguay'),
(233, 'UZ', 'Uzbekistan'),
(234, 'VU', 'Vanuatu'),
(235, 'VA', 'Vatican City State'),
(236, 'VE', 'Venezuela'),
(237, 'VN', 'Vietnam'),
(238, 'VG', 'Virgin Islands (British)'),
(239, 'VI', 'Virgin Islands (U.S.)'),
(240, 'WF', 'Wallis and Futuna Islands'),
(241, 'EH', 'Western Sahara'),
(242, 'YE', 'Yemen'),
(243, 'ZR', 'Zaire'),
(244, 'ZM', 'Zambia'),
(245, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `leeds`
--

CREATE TABLE IF NOT EXISTS `leeds` (
  `id` int(11) NOT NULL,
  `location` varchar(45) DEFAULT NULL,
  `size` varchar(45) DEFAULT NULL,
  `building_size` varchar(45) DEFAULT NULL,
  `service_required` varchar(45) DEFAULT NULL,
  `finish_type` varchar(45) DEFAULT NULL,
  `construction_priority` varchar(45) DEFAULT NULL,
  `construction_type` varchar(45) DEFAULT NULL,
  `lead_type` varchar(45) DEFAULT NULL,
  `project_type` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `interior_design_required` varchar(45) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user_id`),
  KEY `fk_leeds_user1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leeds`
--

INSERT INTO `leeds` (`id`, `location`, `size`, `building_size`, `service_required`, `finish_type`, `construction_priority`, `construction_type`, `lead_type`, `project_type`, `status`, `date_created`, `interior_design_required`, `user_id`) VALUES
(2, 'Lahore', '25kg', '2 marlas', 'no', 'ordinary', 'yes', 'construction', 'Need Contractor', 'Need Contractor', '1', '0000-00-00 00:00:00', 'Yes', 1),
(3, 'Rawalpindi', '1 Kanal ', 'No', 'at labor rate', 'Premium Finishes $$$ ', '2-3 Months ', 'Renovation', 'Need Contractor', 'Interior Design Project ', '1', '0000-00-00 00:00:00', 'No  (Please note it might add to the overall ', 49),
(4, 'Faisalabad', '10 Marla ', 'No', 'at labor rate', 'Luxury Finishes $$$$ ', 'Immediately ', ' New Construction', 'Need Contractor', ' House ', '1', '2017-05-05 00:00:00', ' Yes', 33),
(5, 'Faisalabad', '10 Marla ', 'No', 'at labor rate', 'Luxury Finishes $$$$ ', 'Immediately ', ' New Construction', 'Need Contractor', ' House ', '1', '2017-05-02 00:00:00', ' Yes', 33);

-- --------------------------------------------------------

--
-- Table structure for table `leed_assignments`
--

CREATE TABLE IF NOT EXISTS `leed_assignments` (
  `id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `leeds_id` int(11) NOT NULL,
  `leeds_user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`leeds_id`,`leeds_user_id`),
  KEY `fk_leed_assignments_leeds1` (`leeds_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leed_assignments`
--

INSERT INTO `leed_assignments` (`id`, `date_created`, `status`, `leeds_id`, `leeds_user_id`) VALUES
(1, '2017-06-06 09:43:40', '1', 2, 55);

-- --------------------------------------------------------

--
-- Table structure for table `manufacturers`
--

CREATE TABLE IF NOT EXISTS `manufacturers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user_id`),
  KEY `fk_manufacturers_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `manufacturers`
--

INSERT INTO `manufacturers` (`id`, `user_id`) VALUES
(1, 14),
(2, 15),
(4, 27),
(5, 36),
(6, 57),
(7, 59),
(8, 63),
(9, 64),
(10, 65),
(11, 66);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` text NOT NULL,
  `long_description` text NOT NULL,
  `actual_price` varchar(20) NOT NULL,
  `banjaiga_price` varchar(20) NOT NULL,
  `starting_from` int(10) NOT NULL DEFAULT '0',
  `sizweight` varchar(100) NOT NULL,
  `material` varchar(100) NOT NULL,
  `style` varchar(100) NOT NULL,
  `sku` varchar(45) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `availability` varchar(100) NOT NULL,
  `product_categories_id` int(11) NOT NULL,
  `product_vendors_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `manufacturers_id` int(10) NOT NULL,
  `featured_image` varchar(100) NOT NULL,
  `is_recommended` int(11) NOT NULL DEFAULT '0',
  `is_multiple` int(10) NOT NULL DEFAULT '0',
  `unit_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`product_categories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `long_description`, `actual_price`, `banjaiga_price`, `starting_from`, `sizweight`, `material`, `style`, `sku`, `date_created`, `status`, `availability`, `product_categories_id`, `product_vendors_id`, `brand_id`, `manufacturers_id`, `featured_image`, `is_recommended`, `is_multiple`, `unit_id`) VALUES
(3, 'Hip House', 'Eupen, Belgium', 'Subway tile was first used in 1904 when the New York City Subway System opened. Subway tile was chosen for its durability and its smooth surface which was easy to clean. Manufacturers have increased the size and durability of subway tile since its introduction in the early 1900''s. Subway tile has become largely used in houses around the world due to its versatility.', '22', '20', 33, 'W 3" / D 6" / H 0" / 8 oz.', 'Ceramic', 'Contemporary', '2323', '2017-05-08 00:00:00', '1', '1', 1, 3, 1, 14, '14968185725937a38cd4e168.07032873.jpg', 1, 0, 12),
(11, 'Living Room', 'Zurich, Switzerland', 'long description', '65', '59', 55, 'Siz Weight', 'Ceramic', 'Contemporary', '786', '2017-04-13 00:00:00', '1', '1', 11, 10, 3, 14, '1497522342594260a6918061.88805005.jpg', 0, 0, 3),
(12, 'Villa Pu', 'Amsterdam, Netherland', 'Long Description', '98', '100', 102, 'sw', 'Ceramic', 'Style', '456', '2017-04-19 00:00:00', '1', '1', 1, 9, 4, 15, '149672724859363ed0a9c368.00319930.jpg', 0, 1, 18),
(19, 'Beola Grey', 'Matt, Lappato & Structured', 'Subway tile was first used in 1904 when the New York City Subway System opened. Subway tile was chosen for its durability and its smooth surface which was easy to clean. Manufacturers have increased the size and durability of subway tile since its introduction in the early 1900''s. Subway tile has become largely used in houses around the world due to its versatility.', '91', '90', 95, '60x120cm . 60x60cm . 30x60cm . 80x80cm', 'Ceramic', 'Contemporary', '999', '2017-04-18 12:49:44', '1', '1', 1, 7, 5, 57, '149750447159421ad71ccb11.49772710.jpg', 0, 0, 1),
(20, 'product10', 'Description', 'Long Description', '70', '74', 65, 'Siz Weight', 'Ceramic', 'Style', '1010', '2017-04-18 12:51:14', '1', '1', 2, 6, 6, 14, '149750438959421a851b9426.18752138.jpg', 0, 1, 16),
(21, 'product11', '', '', '', '', 0, '', '', '', '1111', '2017-04-18 12:53:04', '1', '', 3, 5, 7, 0, '', 0, 0, 0),
(24, 'product12', '', '', '', '', 0, '', '', '', '1212', '2017-04-18 13:09:39', NULL, '', 5, 4, 0, 0, '', 0, 0, 0),
(25, 'product13', '', '', '', '', 0, '', '', '', '1313', '2017-04-18 13:10:43', '', '', 6, 25, 1, 0, '1494920785591aae5127b694.30789800.jpg', 0, 0, 0),
(28, 'Testing', 'Matt, Lappato & Structured\r\n60x120cm . 60x60cm . 30x60cm . 80x80cm', 'Subway tile was first used in 1904 when the New York City Subway System opened. Subway tile was chosen for its durability and its smooth surface which was easy to clean. Manufacturers have increased the size and durability of subway tile since its introduction in the early 1900''s. Subway tile has become largely used in houses around the world due to its versatility.', '88', '89', 90, '60x120cm . 60x60cm . 30x60cm . 80x80cm  ', 'Ceramic', 'Contemporary', 'sku', '2017-04-26 10:04:02', '1', '', 12, 12, 1, 65, '15008934555975d10f316994.95746716.jpg', 1, 0, 17),
(29, 'Wave', 'Matt, Lappato & Structured\r\n60x120cm . 60x60cm . 30x60cm . 80x80cm', 'Subway tile was first used in 1904 when the New York City Subway System opened. Subway tile was chosen for its durability and its smooth surface which was easy to clean. Manufacturers have increased the size and durability of subway tile since its introduction in the early 1900''s. Subway tile has become largely used in houses around the world due to its versatility.', '', '', 0, 'W 3" / D 6" / H 0" / 8 oz.', 'Ceramic', 'Contemporary', 'N-GWV-05', '2017-05-08 13:11:19', '1', '', 13, 13, 3, 0, '1497522426594260fa46f5a9.41006070.jpg', 0, 0, 0),
(30, 'Kitchen soemthing', 'This is description', 'Long Description', '', '', 0, 'Siz Weight', 'Material', 'Style', '001-002', '2017-05-09 05:54:37', '1', '', 14, 14, 4, 0, '14968187565937a444541f02.50255853.jpg', 1, 0, 0),
(31, 'Simplicia', 'this is description.', 'long this is description.', '22', '20', 1, 'Siz Weight', 'Material', 'Style', '005', '2017-05-09 06:44:58', '1', '', 15, 15, 5, 0, '14968189275937a4ef882fc1.56096803.jpg', 1, 0, 0),
(32, 'Kitvhen Aloovah', '', '', '', '', 0, '', '', '', '122345', '2017-05-09 09:43:35', '1', '', 16, 16, 0, 0, '1496922217593938695ca438.14997894.jpg', 1, 0, 0),
(33, 'matress', 'asdfasdfasd', 'asdfasdfasd', '', '', 0, '', 'stone, plastic, PVC', 'contemporary, modern, traditional', '11111', '2017-05-10 06:15:56', '1', '1', 17, 17, 0, 0, '', 0, 0, 0),
(34, 'new test product', '', '', '', '', 0, '', '', '', '3333', '2017-05-15 07:33:17', '1', '', 18, 18, 0, 0, '1496922312593938c8d22a53.82860709.jpg', 0, 0, 0),
(36, 'Simplicia', 'this is description.', 'long this is description.', '', '', 0, 'Siz Weight', 'Material', 'contemporary, modern, traditional', '001-001', '2017-05-15 12:59:03', '1', '1', 19, 19, 7, 0, '1496922366593938fe955da8.58992657.jpg', 0, 0, 0),
(37, 'yellow kitchens', 'description', '', '', '', 0, '', '', 'contemporary, traditional, modern', '2223333', '2017-05-26 09:50:53', '1', '', 20, 20, 6, 0, '1496922407593939274abc29.25237295.jpg', 0, 0, 0),
(38, 'Grey Tiles', 'Exquisite wall tiles for your home', 'These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. These are the best tiles you''d ever find around. ', '', '', 0, '8 x 12 inch', 'Graphite', 'Washed out', 'GT1234', '2017-05-27 10:04:24', '1', '1', 21, 21, 1, 0, '14975224775942612ddf6d29.58335770.jpg', 0, 0, 0),
(39, 'Montblanc Bedroom Furniture Set', '', 'The light and shiny finish of the Koto? veneer stylishly dresses up “MONT BLANC”, the new collection by ALFGROUP to furnish the entire home. A complete collection that meets the needs of every room in a Home.\r\n ', '', '', 0, 'Varies', 'wood, fabric,  ', 'contemporary, modern, ', '', '2017-05-30 12:12:13', '1', '1', 22, 22, 4, 0, '14968184815937a3319cd183.57862274.jpg', 1, 0, 0),
(40, 'neww tesitnf', '', '', '', '', 0, '', '', '', '', '2017-06-01 15:27:48', '1', '', 23, 23, 0, 0, '14975225545942617a0738b7.51439215.jpg', 0, 0, 0),
(41, 'dfasfdas', '', '', '', '', 0, '', '', '', 'adfasdf', '2017-06-04 16:46:40', '1', '', 24, 24, 0, 0, '149750444859421ac03da836.95972077.jpg', 0, 0, 0),
(42, 'Prime bed colelction', '', '', '', '', 0, 'varies', 'wood, steel', 'modern, contemporary', 'sada', '2017-06-06 12:50:29', '1', '', 25, 25, 5, 0, '14967535575936a595b57e99.18912869.jpg', 0, 0, 0),
(43, 'Tooti', '', 'asdfahsd flkjahs dfaksdflkas dkfakjsdfjk as', '1200', '800', 0, '5X16', 'metal', 'modern', '123-4456', '2017-06-08 12:42:57', '1', '', 26, 26, 6, 0, '14976094895943b511ba4827.42907400.jpg', 1, 0, 0),
(44, 'New thing on the block', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ', '1500', '999', 800, '', '', '', '', '2017-06-13 09:45:52', '', '', 27, 27, 0, 0, '', 0, 1, 0),
(45, 'Ivanka Porous Panel', '', 'IVANKA company group has a 360-degree approach to its projects, giving complete, full circle services to its Clients.\r\nBeside the serial production and custom manufacturing of high-quality concrete products, IVANKA provides high service in architecture, design and engineering, research and development, technological innovation, packaging, worldwide shipping, project management and installation.\r\n\r\nIVANKA gives full support to the architect and designer community, from the first detailed studying of each project - in terms of feasibility and pricing – to the working out of the best possible solution for the physical realization of even the most challenging creations of design.\r\n\r\nA winning combination: while raising annual production capacity to the industrial level of 150.000 m2, the company preserved its flexibility for customization as key part of the DNA of the IVANKA brand from its inception.', 'N/A', 'N/A', 0, '80 X 80 cm, 80 X 120 cm', 'concrete, metal, fibre', 'modern, contemporary, minimalist', '001-001', '2017-06-19 15:49:01', '1', '1', 27, 27, 0, 63, '14978878795947f487de35a5.12409501.jpg', 1, 0, 44),
(46, 'Boniq Facade Panel', '', 'Influenced by riveted steel truss bridges and particularly by the structure of the iconic Eiffel Tower, this special panel evokes the industrial, robust appearance of steel beams, while retaining the possibility to be applied as a facade cladding panel either to a substructure (ventilated facades) or directly to structural walls.', '', 'N/A', 0, '', 'concrete', 'modern, contemporary, minimalist', 'asdasd', '2017-06-20 09:49:41', '1', '1', 28, 28, 0, 63, '14979524425948f0ba108cd7.90889084.jpg', 1, 0, 44),
(47, 'Engraved Panel', '', 'IVANKA PANELS are produced with a well mastered manufacturing process that combines intelligent technologies with the finishing touch of human hands. This special material is made of a high-performance glass fibre reinforced IVANKA Concrete using a special formula.\r\n\r\nIt is enduring, fire- and corrosion-proof. Due to its extremely long lifespan, low maintenance need and high-level fire safety, it can be equally used for ventilated facades, exterior cladding systems, outdoor or indoor decorative surfaces.', '', '', 0, '80 X 80 cm, 80 X 120 cm', 'concrete', '', '001-002', '2017-06-20 10:18:18', '1', '', 29, 29, 0, 63, '14979539475948f69bde4958.89425197.jpg', 1, 0, 44),
(48, 'HEXXXA-3D', '', 'HEXXXA-3D tile was born with a wish to appeal to the sense of symmetry and love toward geometric shapes, with our ever-present artistic air, stirring up the surface, and creating a system that not only occupies a plane, but reaches out into the space it inhabits.\r\n\r\nHEXXXA-3D is a true statement to our love for the inherent robustness of concrete, and our commitment toward breaking conventions in the approach to this amazing material. Such an innovative shape has the ability to unleash the fantasy of designers – and we are truly happy to see this fantasy realized in first-class projects worldwide.', '', '', 0, '', '', '', '', '2017-06-20 10:41:24', '1', '', 30, 30, 0, 63, '14979553945948fc42b504c1.51968993.jpg', 0, 0, 0),
(49, 'Trinity ', '', 'Trinity tiles explore the depths of meticulous designs in a seemingly easily mastered realm – the 2D-surface of a oor. A single plane – and yet, with the intricate variations in the shapes of Trinity, it can deliver an appealing source of challenges for a creative mind, and an unending source of beauty for the observer of a complete creation. Combining three geometric shapes – a triangle, a parallelogram and a trapeze – the designer can direct attention, and structure the plane to be in line with the space design concept that will be installed beside it. Trinity is a prime opportunity to reach out from the conventional world of rectangles on floors, diving into yet another creative opportunity brought by IVANKA to designers all over the Globe.', 'N/A', 'N/A', 0, '80 X 80 cm, 80 X 120 cm', 'concrete', 'modern, contemporary, minimalist', '110-110', '2017-06-20 10:55:04', '1', '1', 31, 31, 0, 63, '14979562685948ffacc74c21.74856130.jpg', 1, 0, 44),
(50, 'RUDAS', '', 'PERFORATED PANELS offer the opportunity to create truly unique project items, or even designs that are a signature element of a given designer, architect or design practice. IVANKA is open to any and all development initiatives, and through a number of projects involving perforated panels, has developed profound expertise in their creation and design.\r\n\r\nIVANKA PERFORATED elements have complete visual compatibility with IVANKA PANELS – high repeatability of the produced elements and the combination with panels offer builders an economical and highly decorative solution for the whole building envelope.', '', '', 0, '80 X 80 cm, 80 X 120 cm', '', 'modern, contemporary, minimalist', '110-001', '2017-06-20 11:01:43', '1', '1', 32, 32, 0, 63, '14979566855949014d7d0886.25892468.jpg', 0, 0, 0),
(51, 'Orto', '', 'On a micro-scale, the pattern on the surface of ORTO LIVING COVERING represents the beautiful network of casual splits in nature, as water makes its way through the ground.\r\n\r\nThe macro-level inspirations for this design were ortographical photos taken from high above. Through its firm structure, weight and durability, concrete represents the notion of passive strength by its resistance to external forces as a perfect complement to active forces, the life energy of every living being.', '', '', 0, '', 'concrete', '', '001-002', '2017-06-20 11:13:12', '1', '1', 33, 33, 0, 63, '149795727259490398e71de9.90106885.jpg', 0, 0, 0),
(52, 'Opusterra', '', 'IVANKA PANELS are produced with a well mastered manufacturing process that combines intelligent technologies with the finishing touch of human hands. This special material is made of a high-performance glass fibre reinforced IVANKA Concrete using a special formula.\r\n\r\nIt is enduring, fire- and corrosion-proof. Due to its extremely long lifespan, low maintenance need and high-level fire safety, it can be equally used for ventilated facades, exterior cladding systems, outdoor or indoor decorative surfaces.', '', '', 0, '', '', '', '', '2017-06-20 11:24:00', '1', '1', 34, 34, 0, 63, '1497958085594906c5e6c7a5.80823870.jpg', 1, 0, 0),
(53, 'Siena', '', 'Wallcovering. \r\nCoating for exterior and interior. \r\nWall concrete tiles.\r\nGiven the characteristics of aggregates and their photographic reproduction, there may be slight variations in particle size and tone.', '', '', 0, '290x90 MM', 'stone', 'modern, contemporary, minimalist, traditional', '001-002', '2017-06-20 12:49:46', '1', '1', 35, 35, 0, 64, '149796308859491a502244a9.24104897.jpg', 0, 0, 0),
(54, 'Royal', '', 'Wall concrete tiles for exterior and interior. \r\nGiven the characteristics of aggregates and their photographic reproduction, there may be slight variations in particle size and tone.', '', '', 0, '290x90 MM', '', 'modern, contemporary, minimalist, traditional', '110-001', '2017-06-20 12:55:15', '1', '1', 36, 36, 0, 64, '149796339759491b85aef907.18417208.jpg', 0, 0, 44),
(55, 'Luna', '', 'Wall concrete tiles for exterior and interior. \r\nGiven the characteristics of aggregates and their photographic reproduction, there may be slight variations in particle size and tone.', '', '', 0, '290x90 MM', '', 'modern, contemporary, minimalist, traditional', '001-001', '2017-06-20 13:00:52', '1', '1', 37, 37, 0, 64, '149796372759491ccf800216.77905902.jpg', 0, 0, 44),
(56, 'Leaves', '', 'Delicate porcelain sheets are floating in space amid a series of vertical lines.\r\nA sensual, delicate light object and a special highlight for a variety of settings, like foyers, stairwells or lounge areas. The object’s size and illumination technique as well as the design of its individual components can be adapted to the requirements of the room and situation.', '1500', '1200', 0, '', '', '', '110-001', '2017-06-20 14:00:19', '1', '1', 38, 38, 0, 66, '149796727059492aa66228e4.92613956.jpg', 0, 1, 43),
(57, 'Daylight landscape', '', 'Simulating an opening in the wall with a view of the surrounding landscape, DAYLIGHT is composed of a porcelain relief, lit from the back by an LED panel. The motif LANDSCAPE shows a meditative image of gently undulating hills or sand dunes, the motif SKY is a photo-realistic cloudscape.\r\n\r\nThe standard suspension is made from white coated aluminum, where the sheet slips into the frame from the side, allowing you to see the edge of the fine porcelain while letting out a small strip of light.', '', '', 0, '', '', '', '', '2017-06-20 14:03:22', '1', '0', 39, 39, 0, 66, '149796757259492bd4843268.47186142.jpg', 0, 0, 0),
(58, 'aaabbb test', '', '', '', '', 0, '', '', '', '1112-3003', '2017-07-27 11:56:34', '1', '', 40, 40, 0, 0, '', 0, 0, 0),
(59, 'aaabbb test', '', '', '', '', 0, '', '', '', '1112-3003', '2017-07-27 12:32:11', '1', '', 41, 41, 0, 0, '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_catalogue`
--

CREATE TABLE IF NOT EXISTS `product_catalogue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `catalogue` varchar(100) NOT NULL,
  `catalogue_image` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_catalogue_product1` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `product_catalogue`
--

INSERT INTO `product_catalogue` (`id`, `product_id`, `name`, `catalogue`, `catalogue_image`, `date_created`) VALUES
(1, 31, 'adsfdsf', '1496741877593677f5e41ad5.19362154.pdf', '', '0000-00-00 00:00:00'),
(2, 42, '', '14967534935936a5550b76f0.98466810.pdf', '', '0000-00-00 00:00:00'),
(3, 3, 'Catalogue of Hip house', '14967539015936a6ed96a1d2.16315919.pdf', '', '0000-00-00 00:00:00'),
(4, 3, 'instruction of hip house', '14967539015936a6eda2efb8.68033489.pdf', '', '0000-00-00 00:00:00'),
(5, 11, 'catalogue of living room', '14967539695936a7319e7661.54596777.pdf', '', '0000-00-00 00:00:00'),
(6, 39, '', '14967551705936abe264bc67.20573670.pdf', '', '0000-00-00 00:00:00'),
(7, 43, '', '149692602559394749c719e0.22374135.pdf', '', '0000-00-00 00:00:00'),
(8, 3, 'Thired catalog', '14979401045948c088c946c4.09545386.pdf', '', '0000-00-00 00:00:00'),
(10, 45, 'Ivanka Technical guide', '14979474115948dd13cc3d63.70381730.pdf', '', '0000-00-00 00:00:00'),
(11, 45, 'Ivanka Panels catalogue', '14979474115948dd13d81a25.23718613.pdf', '', '0000-00-00 00:00:00'),
(12, 46, 'Bomiq 01', '14979522265948efe2017ba0.66114934.pdf', '', '0000-00-00 00:00:00'),
(13, 46, 'Nomiq 02', '14979522265948efe20d61c4.18789935.pdf', '', '0000-00-00 00:00:00'),
(14, 47, 'Technical Details', '14979540565948f7084316a8.16253448.pdf', '', '0000-00-00 00:00:00'),
(15, 47, 'Ivanka panels', '14979540565948f7084f4349.92399628.pdf', '', '0000-00-00 00:00:00'),
(16, 48, 'Hexxxa-3d Information', '14979555025948fcaec24970.50478346.pdf', '', '0000-00-00 00:00:00'),
(17, 49, 'Trinity Datasheet', '14979563325948ffec1bb642.03355314.pdf', '', '0000-00-00 00:00:00'),
(18, 50, 'Rudus technical sheet', '149795672059490170392e83.73103776.pdf', '', '0000-00-00 00:00:00'),
(19, 52, 'Technical information', '1497958160594907101c8dc8.90514682.pdf', '', '0000-00-00 00:00:00'),
(20, 53, 'Technical sheet', '149796314059491a84673e90.85190552.pdf', '', '0000-00-00 00:00:00'),
(21, 54, 'Technical details', '149796349859491bea5a5682.60988275.pdf', '', '0000-00-00 00:00:00'),
(22, 55, 'Technical Sheet', '149796378559491d09b5ba60.04728294.pdf', '', '0000-00-00 00:00:00'),
(23, 57, '', '', '', '0000-00-00 00:00:00'),
(24, 37, 'Product catalog', '150053218159704dd57d3093.52316550.pdf', '', '0000-00-00 00:00:00'),
(25, 45, 'hsgdfjahsgdf', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE IF NOT EXISTS `product_categories` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`categories_id`,`products_id`),
  KEY `fk_product_categories_categories1` (`categories_id`),
  KEY `fk_product_categories_products1` (`products_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `categories_id`, `products_id`) VALUES
(11, 4, 11),
(12, 4, 28),
(13, 4, 29),
(14, 4, 30),
(21, 4, 38),
(23, 4, 40),
(24, 4, 41),
(15, 5, 31),
(16, 5, 32),
(18, 5, 34),
(19, 5, 36),
(20, 5, 37),
(26, 5, 43),
(40, 5, 58),
(41, 5, 59),
(16, 9, 32),
(18, 9, 34),
(19, 9, 36),
(20, 9, 37),
(26, 9, 43),
(40, 9, 58),
(11, 10, 11),
(21, 10, 38),
(16, 13, 32),
(19, 13, 36),
(20, 14, 37),
(2, 15, 20),
(22, 15, 39),
(25, 15, 42),
(2, 17, 20),
(22, 17, 39),
(25, 17, 42),
(2, 18, 20),
(38, 20, 56),
(39, 20, 57),
(1, 23, 3),
(27, 23, 45),
(28, 23, 46),
(30, 23, 48),
(31, 23, 49),
(32, 23, 50),
(33, 23, 51),
(35, 23, 53),
(36, 23, 54),
(37, 23, 55),
(1, 24, 3),
(30, 24, 48),
(31, 24, 49),
(32, 24, 50),
(33, 24, 51),
(29, 25, 47),
(34, 25, 52),
(35, 26, 53),
(36, 26, 54),
(37, 26, 55);

-- --------------------------------------------------------

--
-- Table structure for table `product_manufacturers`
--

CREATE TABLE IF NOT EXISTS `product_manufacturers` (
  `id` int(11) NOT NULL,
  `manufacturers_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`manufacturers_id`,`products_id`),
  KEY `fk_product_manufacturers_manufacturers1` (`manufacturers_id`),
  KEY `fk_product_manufacturers_products1` (`products_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_pictures`
--

CREATE TABLE IF NOT EXISTS `product_pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(45) DEFAULT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `products_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`products_id`),
  KEY `fk_product_pictures_products1` (`products_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=382 ;

--
-- Dumping data for table `product_pictures`
--

INSERT INTO `product_pictures` (`id`, `file`, `date_created`, `status`, `products_id`) VALUES
(98, '1494920782591aae4eca24b9.30494752.jpg', '2017-05-16 07:46:22', '1', 25),
(99, '1494920785591aae5127b694.30789800.jpg', '2017-05-16 07:46:25', '1', 25),
(100, '1494920787591aae53a16088.25939704.jpg', '2017-05-16 07:46:27', '1', 25),
(164, '149672716959363e8187acd2.38803290.jpg', '2017-06-06 05:32:49', '1', 19),
(165, '149672717159363e83a6cdd4.85405510.jpg', '2017-06-06 05:32:51', '1', 19),
(166, '149672717359363e85a3f388.39826511.jpg', '2017-06-06 05:32:53', '1', 19),
(167, '149672724559363ecd6a0705.48240500.jpg', '2017-06-06 05:34:05', '1', 12),
(168, '149672724859363ed0a9c368.00319930.jpg', '2017-06-06 05:34:08', '1', 12),
(169, '149672725159363ed32648e6.26572809.jpg', '2017-06-06 05:34:11', '1', 12),
(210, '1496729005593645ad9275d1.82161420.jpg', '2017-06-06 06:03:25', '1', 41),
(211, '1496729007593645af6da836.77292357.jpg', '2017-06-06 06:03:27', '1', 41),
(212, '1496729009593645b1e175b2.45523293.jpg', '2017-06-06 06:03:30', '1', 41),
(213, '14967535495936a58d574e01.01794506.jpg', '2017-06-06 12:52:29', '1', 42),
(214, '14967535505936a58e3cebe1.88329549.jpg', '2017-06-06 12:52:31', '1', 42),
(215, '14967535515936a58f277327.52378230.jpg', '2017-06-06 12:52:31', '1', 42),
(216, '14967535515936a58fb3fce2.29386335.jpg', '2017-06-06 12:52:31', '1', 42),
(217, '14967535555936a5937cdaf0.76659950.jpg', '2017-06-06 12:52:36', '1', 42),
(218, '14967535565936a59454fc16.69658729.jpg', '2017-06-06 12:52:36', '1', 42),
(219, '14967535575936a59539e511.93716928.jpg', '2017-06-06 12:52:37', '1', 42),
(220, '14967535575936a595b57e99.18912869.jpg', '2017-06-06 12:52:38', '1', 42),
(221, '14967535615936a599842537.05735830.jpg', '2017-06-06 12:52:42', '1', 42),
(226, '14968184795937a32f0b7eb1.77807256.jpg', '2017-06-07 06:54:39', '1', 39),
(227, '14968184815937a3319cd183.57862274.jpg', '2017-06-07 06:54:42', '1', 39),
(228, '14968184845937a3346815f7.25237628.jpg', '2017-06-07 06:54:44', '1', 39),
(229, '14968184865937a336f13dd6.38508400.jpg', '2017-06-07 06:54:47', '1', 39),
(230, '14968185725937a38cd4e168.07032873.jpg', '2017-06-07 06:56:13', '1', 3),
(231, '14968185765937a3905e6958.61185912.jpg', '2017-06-07 06:56:16', '1', 3),
(232, '14968185785937a392e7a6f9.98874262.jpg', '2017-06-07 06:56:19', '1', 3),
(233, '14968187565937a444541f02.50255853.jpg', '2017-06-07 06:59:16', '1', 30),
(234, '14968187585937a4464a0509.01996698.jpg', '2017-06-07 06:59:18', '1', 30),
(235, '14968187605937a448405d98.05329552.jpg', '2017-06-07 06:59:20', '1', 30),
(236, '14968187625937a44a143c41.08226795.jpg', '2017-06-07 06:59:22', '1', 30),
(242, '14968189275937a4ef882fc1.56096803.jpg', '2017-06-07 07:02:08', '1', 31),
(243, '14968189285937a4f070d725.88311740.jpg', '2017-06-07 07:02:09', '1', 31),
(244, '14968189315937a4f3c93bf2.95018368.jpg', '2017-06-07 07:02:12', '1', 31),
(245, '14968189325937a4f4b264f1.03048227.jpg', '2017-06-07 07:02:13', '1', 31),
(246, '14968189355937a4f7c74a52.33033473.jpg', '2017-06-07 07:02:16', '1', 31),
(247, '14968189365937a4f8ac9c68.98172760.jpg', '2017-06-07 07:02:17', '1', 31),
(248, '14968189395937a4fb915c84.37840898.jpg', '2017-06-07 07:02:19', '1', 31),
(249, '14968189425937a4fe94bdc7.52281926.jpg', '2017-06-07 07:02:22', '1', 31),
(250, '14968189445937a500e73e83.13452993.jpg', '2017-06-07 07:02:25', '1', 31),
(251, '14968189475937a503221000.41498746.jpg', '2017-06-07 07:02:27', '1', 31),
(252, '14968189495937a5055288a0.19882582.jpg', '2017-06-07 07:02:29', '1', 31),
(253, '14968189505937a506d3b6b5.55911569.jpg', '2017-06-07 07:02:30', '1', 31),
(254, '1496922217593938695ca438.14997894.jpg', '2017-06-08 11:43:37', '1', 32),
(255, '14969222195939386beb0723.82603816.jpg', '2017-06-08 11:43:40', '1', 32),
(256, '14969222225939386ee65a42.03306073.jpg', '2017-06-08 11:43:43', '1', 32),
(257, '1496922226593938722d0862.03685560.jpg', '2017-06-08 11:43:46', '1', 32),
(258, '14969222295939387570a9f1.01474243.jpg', '2017-06-08 11:43:49', '1', 32),
(259, '1496922232593938784868c4.56630044.jpg', '2017-06-08 11:43:52', '1', 32),
(260, '14969222355939387b2941b6.29459393.jpg', '2017-06-08 11:43:55', '1', 32),
(261, '14969222375939387dad9752.47597106.jpg', '2017-06-08 11:43:58', '1', 32),
(262, '1496922240593938809e65c1.97994908.jpg', '2017-06-08 11:44:00', '1', 32),
(263, '149692224359393883192e04.83224280.jpg', '2017-06-08 11:44:03', '1', 32),
(264, '1496922312593938c8d22a53.82860709.jpg', '2017-06-08 11:45:13', '1', 34),
(265, '1496922313593938c96c7f55.75487548.jpg', '2017-06-08 11:45:13', '1', 34),
(266, '1496922316593938cc49b815.90773659.jpg', '2017-06-08 11:45:16', '1', 34),
(267, '1496922366593938fe955da8.58992657.jpg', '2017-06-08 11:46:06', '1', 36),
(268, '1496922407593939274abc29.25237295.jpg', '2017-06-08 11:46:48', '1', 37),
(269, '14969224085939392851ce03.36623752.jpg', '2017-06-08 11:46:49', '1', 37),
(270, '14969224115939392bdfba48.05831207.jpg', '2017-06-08 11:46:52', '1', 37),
(271, '14969224125939392ce2c1a1.99421855.jpg', '2017-06-08 11:46:53', '1', 37),
(276, '1497504018594219120de4c0.46085447.jpg', '2017-06-15 05:20:18', '1', 20),
(277, '149750438959421a851b9426.18752138.jpg', '2017-06-15 05:26:29', '1', 20),
(278, '149750444859421ac03da836.95972077.jpg', '2017-06-15 05:27:28', '1', 41),
(279, '149750447159421ad71ccb11.49772710.jpg', '2017-06-15 05:27:51', '1', 19),
(280, '149750488259421c723d6a04.70608623.jpg', '2017-06-15 05:34:42', '1', 44),
(281, '149750488259421c72a08258.62729856.jpg', '2017-06-15 05:34:42', '1', 44),
(282, '149750488659421c76bc0867.64795456.jpg', '2017-06-15 05:34:46', '1', 44),
(283, '149750489259421c7c04a8f3.54071231.jpg', '2017-06-15 05:34:52', '1', 44),
(284, '1497522342594260a6918061.88805005.jpg', '2017-06-15 10:25:42', '1', 11),
(285, '1497522342594260a6e683d8.83940000.jpg', '2017-06-15 10:25:43', '1', 11),
(286, '1497522346594260aa697236.05724534.jpg', '2017-06-15 10:25:46', '1', 11),
(287, '1497522426594260fa46f5a9.41006070.jpg', '2017-06-15 10:27:06', '1', 29),
(288, '1497522427594260fb0b73c8.38555992.jpg', '2017-06-15 10:27:07', '1', 29),
(289, '1497522427594260fb500e83.26029023.jpg', '2017-06-15 10:27:07', '1', 29),
(290, '14975224755942612b28d2c0.64802299.jpg', '2017-06-15 10:27:55', '1', 38),
(291, '14975224775942612ddf6d29.58335770.jpg', '2017-06-15 10:27:58', '1', 38),
(292, '14975225545942617a0738b7.51439215.jpg', '2017-06-15 10:29:14', '1', 40),
(293, '14975225545942617ab1f334.49120505.jpg', '2017-06-15 10:29:15', '1', 40),
(294, '14975225585942617e59d702.29446417.jpg', '2017-06-15 10:29:18', '1', 40),
(295, '14976094895943b511ba4827.42907400.jpg', '2017-06-16 10:38:10', '1', 43),
(296, '14976094905943b512534ae7.70275739.jpg', '2017-06-16 10:38:10', '1', 43),
(297, '14976094935943b515ce1a16.27880175.jpg', '2017-06-16 10:38:14', '1', 43),
(298, '14978878795947f487de35a5.12409501.jpg', '2017-06-19 15:58:00', '1', 45),
(299, '14978878805947f4889702f2.01877059.jpg', '2017-06-19 15:58:01', '1', 45),
(300, '14978878815947f4892abe35.09461944.jpg', '2017-06-19 15:58:01', '1', 45),
(301, '14978878815947f48996e140.88709044.jpg', '2017-06-19 15:58:02', '1', 45),
(302, '14978878825947f48a115a71.04314424.jpg', '2017-06-19 15:58:02', '1', 45),
(303, '14978878825947f48ab69dc3.40209332.jpg', '2017-06-19 15:58:03', '1', 45),
(304, '14979524265948f0aadcee63.94883736.jpg', '2017-06-20 09:53:47', '1', 46),
(305, '14979524405948f0b83b8542.19908704.jpg', '2017-06-20 09:54:00', '1', 46),
(306, '14979524425948f0ba108cd7.90889084.jpg', '2017-06-20 09:54:02', '1', 46),
(308, '14979524465948f0be369683.37889579.jpg', '2017-06-20 09:54:06', '1', 46),
(309, '14979524465948f0beed87b2.90170598.jpg', '2017-06-20 09:54:07', '1', 46),
(311, '14979539465948f69a4f3b91.84410605.jpg', '2017-06-20 10:19:06', '1', 47),
(312, '14979539465948f69abb34b7.70497242.jpg', '2017-06-20 10:19:07', '1', 47),
(313, '14979539475948f69bde4958.89425197.jpg', '2017-06-20 10:19:08', '1', 47),
(314, '14979539525948f6a005aee2.72076001.jpg', '2017-06-20 10:19:12', '1', 47),
(315, '14979539535948f6a1ef40c8.09344469.jpg', '2017-06-20 10:19:14', '1', 47),
(316, '14979553945948fc42b504c1.51968993.jpg', '2017-06-20 10:43:15', '1', 48),
(317, '14979553955948fc43e484f6.86267999.jpg', '2017-06-20 10:43:16', '1', 48),
(318, '14979553975948fc454d9527.26467198.jpg', '2017-06-20 10:43:17', '1', 48),
(319, '14979554115948fc53afa4b3.22857903.jpg', '2017-06-20 10:43:32', '1', 48),
(320, '14979554145948fc5637e9c2.58064185.jpg', '2017-06-20 10:43:34', '1', 48),
(321, '14979554205948fc5c930ba7.79948640.jpg', '2017-06-20 10:43:40', '1', 48),
(322, '14979554235948fc5f704de5.52638614.jpg', '2017-06-20 10:43:43', '1', 48),
(323, '14979562625948ffa694af93.17305671.jpg', '2017-06-20 10:57:43', '1', 49),
(324, '14979562635948ffa712b7b5.01726426.jpg', '2017-06-20 10:57:43', '1', 49),
(325, '14979562635948ffa780bd69.43436585.jpg', '2017-06-20 10:57:43', '1', 49),
(326, '14979562675948ffabddbe12.06898816.jpg', '2017-06-20 10:57:48', '1', 49),
(327, '14979562685948ffacc74c21.74856130.jpg', '2017-06-20 10:57:49', '1', 49),
(328, '14979562715948ffaf5ed249.66235149.jpg', '2017-06-20 10:57:51', '1', 49),
(329, '14979562755948ffb3478520.95669507.jpg', '2017-06-20 10:57:55', '1', 49),
(330, '14979562775948ffb53c2eb3.93372398.jpg', '2017-06-20 10:57:57', '1', 49),
(331, '14979566535949012dc4c860.51141434.jpg', '2017-06-20 11:04:14', '1', 50),
(332, '14979566545949012e5b0d86.23386489.jpg', '2017-06-20 11:04:14', '1', 50),
(333, '14979566555949012fb914d3.71615065.jpg', '2017-06-20 11:04:16', '1', 50),
(334, '149795665659490130c057e9.54770504.jpg', '2017-06-20 11:04:17', '1', 50),
(335, '1497956659594901337608d6.96456659.jpg', '2017-06-20 11:04:19', '1', 50),
(336, '14979566855949014d7d0886.25892468.jpg', '2017-06-20 11:04:45', '1', 50),
(338, '149795725259490384a4ba34.57671788.jpg', '2017-06-20 11:14:13', '1', 51),
(339, '1497957257594903899cb100.74786321.jpg', '2017-06-20 11:14:18', '1', 51),
(340, '149795726759490393a190a3.79745209.jpg', '2017-06-20 11:14:28', '1', 51),
(341, '149795727159490397633b47.69498785.jpg', '2017-06-20 11:14:31', '1', 51),
(342, '1497957272594903986f6774.23729429.jpg', '2017-06-20 11:14:32', '1', 51),
(343, '149795727259490398e71de9.90106885.jpg', '2017-06-20 11:14:33', '1', 51),
(344, '1497957280594903a022f523.90034955.jpg', '2017-06-20 11:14:40', '1', 51),
(345, '1497958075594906bbab02b9.03209146.jpg', '2017-06-20 11:27:56', '1', 52),
(347, '1497958078594906bed6a989.30189434.jpg', '2017-06-20 11:27:59', '1', 52),
(348, '1497958085594906c5e6c7a5.80823870.jpg', '2017-06-20 11:28:06', '1', 52),
(349, '1497958086594906c6615c78.44734740.jpg', '2017-06-20 11:28:06', '1', 52),
(350, '1497958087594906c7458858.51128197.jpg', '2017-06-20 11:28:07', '1', 52),
(351, '1497958088594906c85e55e9.49949216.jpg', '2017-06-20 11:28:08', '1', 52),
(352, '1497958089594906c946ab03.56835277.jpg', '2017-06-20 11:28:09', '1', 52),
(353, '1497958091594906cbe459e4.22935568.jpg', '2017-06-20 11:28:12', '1', 52),
(354, '149796308259491a4aa33804.86605094.jpg', '2017-06-20 12:51:22', '1', 53),
(355, '149796308359491a4b0ed991.22116229.jpg', '2017-06-20 12:51:23', '1', 53),
(356, '149796308559491a4d7078d8.64847408.jpg', '2017-06-20 12:51:26', '1', 53),
(357, '149796308859491a502244a9.24104897.jpg', '2017-06-20 12:51:28', '1', 53),
(358, '149796309659491a589df585.58835373.jpg', '2017-06-20 12:51:37', '1', 53),
(359, '149796339559491b837403b9.68717068.jpg', '2017-06-20 12:56:36', '1', 54),
(360, '149796339659491b84132046.64221146.jpg', '2017-06-20 12:56:36', '1', 54),
(361, '149796339759491b85aef907.18417208.jpg', '2017-06-20 12:56:38', '1', 54),
(362, '149796339859491b86752b76.32089489.jpg', '2017-06-20 12:56:38', '1', 54),
(363, '149796339859491b86d15e04.80835309.jpg', '2017-06-20 12:56:39', '1', 54),
(364, '149796369759491cb15cd031.24759138.jpg', '2017-06-20 13:01:37', '1', 55),
(365, '149796372559491ccda82ea1.00062910.jpg', '2017-06-20 13:02:06', '1', 55),
(366, '149796372659491cce3f7fd1.94057004.jpg', '2017-06-20 13:02:06', '1', 55),
(367, '149796372759491ccf800216.77905902.jpg', '2017-06-20 13:02:08', '1', 55),
(368, '149796374759491ce30802c8.25680923.jpg', '2017-06-20 13:02:27', '1', 55),
(369, '149796726259492a9e6694d7.02291777.jpg', '2017-06-20 14:01:02', '1', 56),
(370, '149796726359492a9fad8dd3.72689430.jpg', '2017-06-20 14:01:04', '1', 56),
(371, '149796726459492aa05ee874.17686756.jpg', '2017-06-20 14:01:04', '1', 56),
(372, '149796726959492aa58724a2.16564854.jpg', '2017-06-20 14:01:09', '1', 56),
(373, '149796727059492aa66228e4.92613956.jpg', '2017-06-20 14:01:10', '1', 56),
(374, '149796756559492bcd29f9f7.72962216.jpg', '2017-06-20 14:06:05', '1', 57),
(375, '149796756559492bcde5cde6.95522073.jpg', '2017-06-20 14:06:06', '1', 57),
(376, '149796757259492bd4843268.47186142.jpg', '2017-06-20 14:06:12', '1', 57),
(377, '149796757359492bd55182b7.27444521.jpg', '2017-06-20 14:06:13', '1', 57),
(378, '15008934425975d102a0d443.94864217.jpg', '2017-07-24 15:50:42', '1', 28),
(379, '15008934455975d105ce0eb2.96359677.jpg', '2017-07-24 15:50:46', '1', 28),
(380, '15008934555975d10f316994.95746716.jpg', '2017-07-24 15:50:55', '1', 28);

-- --------------------------------------------------------

--
-- Table structure for table `product_ratings`
--

CREATE TABLE IF NOT EXISTS `product_ratings` (
  `id` int(11) NOT NULL,
  `rating` varchar(45) DEFAULT NULL,
  `seller_comu` int(10) NOT NULL DEFAULT '0',
  `product_quality` int(10) NOT NULL DEFAULT '0',
  `buy_again` int(10) NOT NULL DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `products_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`products_id`),
  KEY `fk_product_ratings_products1` (`products_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_ratings`
--

INSERT INTO `product_ratings` (`id`, `rating`, `seller_comu`, `product_quality`, `buy_again`, `date_added`, `status`, `products_id`) VALUES
(1, 'this is my review.', 1, 2, 3, '2017-06-16 10:36:07', '1', 19),
(2, 'wonder full item.', 3, 5, 2, '2017-06-16 10:39:19', '1', 43),
(3, 'good product. ', 1, 3, 5, '2017-06-16 11:19:06', '1', 43),
(4, 'good product. ', 5, 2, 3, '2017-06-16 11:19:47', '1', 3),
(5, 'feedback', 2, 1, 5, '2017-06-16 11:21:34', '1', 12),
(6, 'asdfasdfasd', 4, 4, 4, '2017-06-20 14:08:14', '1', 57),
(7, 'this is comment', 3, 2, 5, '2017-06-21 09:50:43', '1', 49),
(8, 'asdasd', 5, 5, 4, '2017-07-04 14:12:42', '1', 52),
(9, 'this is my review.', 5, 4, 1, '2017-07-11 11:45:17', '1', 45),
(10, 'this is my review.', 1, 4, 2, '2017-07-11 11:46:31', '1', 53),
(11, '', 5, 3, 4, '2017-08-01 13:06:30', '1', 38),
(12, '', 4, 4, 2, '2017-08-02 18:02:10', '1', 20),
(13, '', 4, 4, 5, '2017-08-07 13:42:28', '1', 32),
(14, '', 2, 2, 1, '2017-08-09 00:17:58', '1', 42);

-- --------------------------------------------------------

--
-- Table structure for table `product_vendors`
--

CREATE TABLE IF NOT EXISTS `product_vendors` (
  `id` int(11) NOT NULL,
  `vendors_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`vendors_id`,`products_id`),
  KEY `fk_product_vendors_vendors1` (`vendors_id`),
  KEY `fk_product_vendors_products1` (`products_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_vendors`
--

INSERT INTO `product_vendors` (`id`, `vendors_id`, `products_id`) VALUES
(3, 1, 3),
(7, 1, 19),
(9, 1, 12),
(10, 1, 11),
(12, 1, 28),
(13, 1, 29),
(14, 1, 30),
(15, 1, 31),
(16, 1, 32),
(19, 1, 36),
(20, 1, 37),
(21, 1, 38),
(23, 1, 40),
(24, 1, 41),
(25, 16, 42),
(3, 19, 3),
(16, 19, 32),
(18, 19, 34),
(27, 19, 45),
(3, 25, 3),
(23, 25, 40),
(25, 25, 42),
(22, 26, 39),
(21, 27, 38),
(22, 27, 39),
(23, 27, 40),
(14, 28, 30),
(20, 28, 37),
(22, 28, 39),
(3, 29, 3),
(26, 29, 43);

-- --------------------------------------------------------

--
-- Table structure for table `profile_ratings`
--

CREATE TABLE IF NOT EXISTS `profile_ratings` (
  `id` int(11) NOT NULL,
  `date_added` varchar(45) DEFAULT NULL,
  `rating` varchar(45) DEFAULT NULL,
  `comments` varchar(45) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_profiles_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user_profiles_id`),
  KEY `fk_profile_ratings_user_profiles1` (`user_profiles_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL,
  `title` varchar(45) DEFAULT NULL,
  `category` varchar(45) DEFAULT NULL,
  `keywords` varchar(45) DEFAULT NULL,
  `starting_year` varchar(45) DEFAULT NULL,
  `ending_year` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `website` varchar(45) NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `post_date` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `user_vendors_id` int(11) NOT NULL,
  `user_vendors_id1` int(11) NOT NULL,
  `user_builders_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user_id`,`user_vendors_id`,`user_vendors_id1`,`user_builders_id`),
  KEY `fk_projects_user1` (`user_id`,`user_vendors_id`,`user_vendors_id1`,`user_builders_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `category`, `keywords`, `starting_year`, `ending_year`, `country`, `website`, `status`, `date_created`, `post_date`, `user_id`, `user_vendors_id`, `user_vendors_id1`, `user_builders_id`) VALUES
(1, 'firstprojec', '1', 'firspro keye', '2015', '2018', 'Pakis', 'www.example.com', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 33, 4, 15, 16),
(2, 'myNewPoject', '3', 'myNewPoject keywords', '2015', '2018', 'Pakistan', 'www.example.com', '1', '2017-04-20 13:18:21', '2015-05-25 00:00:00', 1, 2, 14, 16),
(3, 'Hip House', '5', 'Eupine Belgium', '2016', '2018', '167', 'http://www.google.com', '1', '2017-05-29 11:38:38', NULL, 2, 1, 0, 0),
(5, 'Grungy Tiles', '5', 'Lahore, Pakistan', '2017', '2018', '167', 'http://www.google.com', '1', '2017-05-30 09:42:09', NULL, 2, 1, 0, 0),
(6, 'Villa Pu', '5', 'Eupine Belgium', '2015', '2016', '167', 'http://www.google.com', '1', '2017-05-30 09:44:02', NULL, 2, 1, 0, 0),
(7, 'ProjectName', '5', 'ProjectName Keywords', '2015', '2018', '', 'http://www.google.com', '1', '2017-06-07 10:33:05', NULL, 38, 0, 1, 0),
(8, 'Hip House', '6', 'this is keyword', '2002', '2006', '167', 'http://www.google.com', '1', '2017-06-07 10:34:20', NULL, 38, 0, 1, 0),
(9, 'Project3', '6', 'dsfasd', '2014', '2016', '16', 'http://www.google.com', '1', '2017-06-07 11:00:51', NULL, 38, 0, 1, 0),
(10, 'Project5', '15', 'keywords', '2014', '2024', '17', 'http://www.google.com', '1', '2017-06-07 11:02:05', NULL, 38, 0, 1, 0),
(11, 'Projects asds 1', 'Category', 'this is key word', '2002', '2013', '1', 'http/www.google.com', '1', '2017-08-03 15:17:01', NULL, 52, 0, 4, 0),
(12, 'asdfasdfa Project 1', '5', 'these are key words', '2012', '2019', '167', 'http://www.google.com', '1', '2017-08-03 15:20:31', NULL, 40, 0, 3, 0),
(13, 'fasdfasdfad project 1', '6', 'these are keywords', '2008', '2014', '167', 'http://www.google.com', '1', '2017-08-03 15:21:56', NULL, 39, 0, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `project_assignments`
--

CREATE TABLE IF NOT EXISTS `project_assignments` (
  `id` int(11) NOT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `projects_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`projects_id`),
  KEY `fk_project_assignments_projects1` (`projects_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project_assignments`
--

INSERT INTO `project_assignments` (`id`, `date_created`, `status`, `projects_id`) VALUES
(1, '2015-02-03', 'Active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `project_pictures`
--

CREATE TABLE IF NOT EXISTS `project_pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(45) DEFAULT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `projects_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`projects_id`),
  KEY `fk_project_pictures_projects1` (`projects_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `project_pictures`
--

INSERT INTO `project_pictures` (`id`, `file`, `date_created`, `status`, `projects_id`) VALUES
(2, '1496057921592c08419987a7.38386735.jpg', '2017-05-29 11:38:41', '1', 3),
(3, '1496057924592c08445bd2b8.84479271.jpg', '2017-05-29 11:38:44', '1', 3),
(4, '1496137126592d3da69f0f17.92374247.jpg', '2017-05-30 09:38:46', '1', 3),
(8, '1496137329592d3e713d7bf3.51784554.jpg', '2017-05-30 09:42:09', '1', 5),
(9, '1496137332592d3e748d78e0.41340227.jpg', '2017-05-30 09:42:12', '1', 5),
(11, '1496137442592d3ee2909db0.33244572.jpg', '2017-05-30 09:44:02', '1', 6),
(12, '1496137446592d3ee659e482.43997651.jpg', '2017-05-30 09:44:06', '1', 6),
(13, '1496137446592d3ee67f3957.98489493.jpg', '2017-05-30 09:44:06', '1', 6),
(14, '1496137493592d3f1577a397.78637445.jpg', '2017-05-30 09:44:53', '1', 5),
(27, '14968322985937d92aa84450.03464401.jpg', '2017-06-07 10:44:58', '1', 8),
(28, '14968323005937d92cf2d1a2.89267531.jpg', '2017-06-07 10:45:01', '1', 8),
(29, '14968323025937d92eb57964.81522707.jpg', '2017-06-07 10:45:03', '1', 8),
(30, '14968327575937daf579e385.87930191.jpg', '2017-06-07 10:52:37', '1', 7),
(31, '14968327595937daf74fd646.31027433.jpg', '2017-06-07 10:52:39', '1', 7),
(32, '14968327605937daf8b2a446.15200178.jpg', '2017-06-07 10:52:40', '1', 7),
(33, '14968332515937dce3757ce3.39803914.jpg', '2017-06-07 11:00:51', '1', 9),
(34, '14968332535937dce5e7f5c5.23957664.jpg', '2017-06-07 11:00:54', '1', 9),
(35, '14968332565937dce876e2b7.98801315.jpg', '2017-06-07 11:00:56', '1', 9),
(36, '14968333255937dd2d5a4c87.59289804.jpg', '2017-06-07 11:02:05', '1', 10),
(37, '14968333275937dd2f9ce2b9.75745366.jpg', '2017-06-07 11:02:07', '1', 10),
(38, '14968333295937dd31770382.43016791.jpg', '2017-06-07 11:02:09', '1', 10),
(39, '15017554215982f81d516bd9.03964828.jpg', '2017-08-03 15:17:01', '1', 11),
(41, '15017554255982f821c5b267.67562882.jpg', '2017-08-03 15:17:05', '1', 11),
(42, '15017554755982f853b7c189.17622768.jpg', '2017-08-03 15:17:56', '1', 11),
(43, '15017556315982f8ef8278f6.22805456.jpg', '2017-08-03 15:20:31', '1', 12),
(44, '15017556345982f8f22a5ba6.74746569.jpg', '2017-08-03 15:20:34', '1', 12),
(45, '15017556365982f8f4a4d2c2.87406841.jpg', '2017-08-03 15:20:36', '1', 12),
(46, '15017557165982f94440e5d9.06220657.jpg', '2017-08-03 15:21:56', '1', 13),
(47, '15017557185982f946c543f1.34443407.jpg', '2017-08-03 15:21:59', '1', 13),
(48, '15017557215982f94958ac03.93790225.jpg', '2017-08-03 15:22:01', '1', 13);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_list_items`
--

CREATE TABLE IF NOT EXISTS `shopping_list_items` (
  `id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_shopping_list_id` int(11) NOT NULL,
  `user_shopping_list_user_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `quantity` int(10) NOT NULL DEFAULT '1',
  `price_offered` int(11) NOT NULL DEFAULT '0',
  `products_product_categories_id` int(11) NOT NULL,
  `assigned_user_id` int(10) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=startingPoint, 2=Waiting fo Quote, 7=Information requested',
  PRIMARY KEY (`id`,`user_shopping_list_id`,`user_shopping_list_user_id`,`products_id`,`products_product_categories_id`),
  KEY `fk_shopping_list_items_user_shopping_list1` (`user_shopping_list_id`,`user_shopping_list_user_id`),
  KEY `fk_shopping_list_items_products1` (`products_id`,`products_product_categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shopping_list_items`
--

INSERT INTO `shopping_list_items` (`id`, `date_created`, `user_shopping_list_id`, `user_shopping_list_user_id`, `products_id`, `quantity`, `price_offered`, `products_product_categories_id`, `assigned_user_id`, `status`) VALUES
(1, '2017-07-28 00:33:31', 34, 9, 19, 12, 0, 1, 2, 2),
(2, '2017-06-13 11:33:19', 1, 33, 11, 1, 0, 11, 26, 0),
(3, '2017-06-13 11:33:24', 1, 33, 20, 1, 0, 2, 2, 0),
(4, '2017-06-15 10:23:49', 1, 33, 28, 3, 0, 12, 0, 2),
(5, '2017-06-15 13:04:21', 3, 33, 32, 1, 0, 16, 0, 0),
(9, '2017-06-16 13:09:44', 6, 62, 30, 1, 0, 14, 0, 0),
(10, '2017-06-16 13:10:36', 7, 62, 3, 1, 0, 1, 0, 0),
(11, '2017-06-16 13:11:09', 7, 62, 34, 1, 0, 18, 0, 0),
(12, '2017-06-16 13:13:45', 8, 62, 19, 1, 0, 1, 0, 0),
(14, '2017-06-16 13:39:12', 8, 62, 43, 1, 0, 26, 0, 0),
(15, '2017-06-16 15:46:40', 10, 62, 40, 2, 0, 23, 0, 0),
(16, '2017-06-16 15:47:38', 5, 62, 40, 2, 0, 23, 0, 0),
(17, '2017-06-16 15:47:50', 5, 62, 30, 1, 0, 14, 0, 0),
(18, '2017-06-16 15:48:09', 5, 62, 32, 1, 0, 16, 0, 0),
(19, '2017-06-16 16:14:44', 5, 62, 3, 1, 0, 1, 0, 0),
(20, '2017-06-19 05:56:08', 5, 62, 43, 1, 0, 26, 0, 0),
(21, '2017-06-20 13:48:39', 9, 62, 46, 2, 0, 28, 0, 0),
(22, '2017-06-20 13:49:26', 9, 62, 54, 1, 0, 36, 0, 0),
(23, '2017-06-21 07:29:29', 9, 62, 52, 2, 0, 34, 0, 0),
(24, '2017-06-21 07:54:29', 15, 33, 3, 1, 0, 1, 0, 0),
(25, '2017-06-21 07:55:06', 16, 33, 3, 4, 0, 1, 0, 0),
(26, '2017-06-21 11:11:11', 17, 62, 52, 1, 0, 34, 0, 0),
(31, '2017-06-21 13:25:26', 9, 62, 55, 1, 0, 37, 0, 0),
(32, '2017-06-21 15:09:29', 9, 62, 56, 2, 0, 38, 0, 0),
(35, '2017-06-23 06:51:46', 1, 33, 19, 1, 0, 1, 0, 2),
(39, '2017-06-23 09:56:20', 1, 33, 49, 1, 0, 31, 0, 2),
(40, '2017-06-23 11:31:13', 1, 33, 3, 4, 0, 1, 0, 0),
(42, '2017-06-29 11:02:37', 16, 33, 46, 3, 0, 28, 0, 0),
(43, '2017-07-01 10:48:54', 18, 67, 55, 1, 0, 37, 0, 2),
(47, '2017-07-04 07:03:23', 18, 67, 30, 1, 0, 14, 0, 0),
(48, '2017-07-04 13:42:41', 18, 67, 40, 1, 0, 23, 0, 0),
(51, '2017-07-05 10:04:43', 24, 33, 3, 1, 18, 1, 0, 0),
(52, '2017-07-05 10:05:34', 25, 33, 3, 1, 0, 1, 0, 0),
(53, '2017-07-05 12:51:21', 26, 67, 57, 1, 0, 39, 0, 2),
(54, '2017-07-05 12:52:29', 27, 67, 56, 1, 1800, 38, 0, 0),
(55, '2017-07-06 13:26:21', 28, 33, 3, 2, 520, 1, 26, 0),
(56, '2017-07-06 13:26:46', 28, 33, 31, 1, 685, 15, 56, 0),
(57, '2017-07-06 13:49:52', 27, 67, 57, 2, 3000, 39, 26, 2),
(58, '2017-07-07 06:29:37', 27, 67, 48, 1, 2000, 30, 26, 2),
(59, '2017-07-07 06:33:11', 27, 67, 39, 1, 3000, 22, 0, 2),
(60, '2017-07-10 14:44:51', 29, 33, 3, 1, 0, 1, 0, 0),
(61, '2017-07-13 19:34:42', 25, 33, 25, 1, 0, 6, 0, 7),
(62, '2017-07-18 23:13:32', 31, 67, 57, 1, 0, 39, 0, 7),
(63, '2017-07-18 23:14:07', 31, 67, 30, 2, 1500, 14, 0, 7),
(64, '2017-07-19 12:33:58', 31, 67, 37, 1, 0, 20, 0, 7),
(65, '2017-07-19 18:45:35', 31, 67, 29, 1, 2500, 13, 2, 7),
(66, '2017-07-19 18:49:27', 31, 67, 45, 1, 0, 27, 0, 0),
(68, '2017-07-19 18:52:50', 33, 67, 56, 3, 1500, 38, 0, 2),
(69, '2017-07-20 11:22:24', 33, 67, 32, 1, 0, 16, 0, 7),
(70, '2017-07-20 11:23:11', 33, 67, 28, 1, 0, 12, 0, 7),
(71, '2017-07-20 11:26:29', 33, 67, 49, 1, 0, 31, 0, 2),
(72, '2017-07-22 01:41:48', 33, 67, 34, 1, 0, 18, 0, 7),
(73, '2017-07-25 17:13:49', 33, 67, 19, 2, 0, 1, 0, 2),
(74, '2017-07-28 00:32:36', 33, 67, 40, 1, 0, 23, 0, 0),
(75, '2017-07-28 01:20:34', 23, 67, 40, 4, 0, 23, 0, 7),
(82, '2017-08-04 01:59:58', 22, 67, 34, 1, 0, 18, 0, 0),
(83, '2017-08-04 11:35:29', 22, 67, 37, 1, 0, 20, 0, 7),
(84, '2017-08-06 20:23:21', 22, 67, 56, 1, 0, 38, 0, 2),
(85, '2017-08-07 11:54:53', 35, 33, 3, 2, 0, 1, 0, 0),
(86, '2017-08-07 11:55:26', 35, 33, 48, 1, 0, 30, 0, 0),
(87, '2017-08-07 11:57:26', 36, 33, 49, 1, 0, 31, 0, 0),
(88, '2017-08-07 12:37:29', 36, 33, 30, 1, 0, 14, 0, 0),
(89, '2017-08-07 13:41:58', 37, 67, 32, 1, 0, 16, 0, 7),
(90, '2017-08-08 14:57:54', 39, 33, 30, 1, 0, 14, 0, 0),
(91, '2017-08-09 00:28:43', 19, 67, 11, 1, 0, 11, 0, 2),
(92, '2017-08-09 02:16:01', 26, 67, 59, 1, 0, 41, 0, 0),
(93, '2017-08-09 02:16:20', 26, 67, 54, 1, 0, 36, 0, 2),
(94, '2017-08-09 02:19:14', 26, 67, 46, 1, 0, 28, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_list_items_info`
--

CREATE TABLE IF NOT EXISTS `shopping_list_items_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created` datetime DEFAULT NULL,
  `shopping_list_item_id` int(11) DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `is_send_price_qoute` int(10) NOT NULL DEFAULT '0',
  `is_general_request` int(10) NOT NULL DEFAULT '0',
  `is_send_catalogue` int(10) NOT NULL DEFAULT '0',
  `is_send_more_info` int(10) NOT NULL DEFAULT '0',
  `is_nearest_dealer` int(10) NOT NULL DEFAULT '0',
  `is_send_spec_sheet` int(10) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `who_are_you` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_shopping_list_item_id` (`shopping_list_item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `shopping_list_items_info`
--

INSERT INTO `shopping_list_items_info` (`id`, `date_created`, `shopping_list_item_id`, `status`, `is_send_price_qoute`, `is_general_request`, `is_send_catalogue`, `is_send_more_info`, `is_nearest_dealer`, `is_send_spec_sheet`, `message`, `who_are_you`) VALUES
(1, '2017-07-13 19:36:01', 61, 1, 1, 1, 0, 0, 1, 1, 'cxzc', 'Interior designer'),
(2, '2017-08-08 15:04:33', 90, 1, 1, 1, 0, 1, 0, 1, 'vxcvcx', 'Architect');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE IF NOT EXISTS `units` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `name`, `date_created`) VALUES
(1, 'Kilogram', '2017-06-09 11:09:41'),
(2, 'Nos', '2017-06-09 11:10:05'),
(3, 'Pieces', '2017-06-09 11:10:29'),
(4, 'Tons', '2017-06-09 11:10:53'),
(5, 'Units', '2017-06-09 11:11:13'),
(6, '20'' Container', '2017-06-09 11:11:39'),
(7, '40'' Container', '2017-06-09 11:11:56'),
(8, 'Bags', '2017-06-09 11:12:14'),
(9, 'Bag', '2017-06-09 11:12:26'),
(10, 'Barrel', '2017-06-09 11:12:43'),
(11, 'Barrels', '2017-06-09 11:13:01'),
(12, 'Bottles', '2017-06-09 11:13:22'),
(13, 'Boxes', '2017-06-09 11:13:41'),
(14, 'Bushel', '2017-06-09 11:13:57'),
(15, 'Bushels', '2017-06-09 11:14:12'),
(16, 'Cartons', '2017-06-09 11:14:35'),
(17, 'Dozens', '2017-06-09 11:14:48'),
(18, 'Foot', '2017-06-09 11:15:04'),
(19, 'Gallons', '2017-06-09 11:15:17'),
(20, 'Grames', '2017-06-09 11:15:28'),
(21, 'Hactare', '2017-06-09 11:15:43'),
(22, 'Kilometer', '2017-06-09 11:16:02'),
(23, 'Kilowatt', '2017-06-09 11:16:22'),
(24, 'Liters', '2017-06-09 11:16:33'),
(25, 'Liter', '2017-06-09 11:16:56'),
(26, 'Long Ton', '2017-06-09 11:17:10'),
(27, 'Meters', '2017-06-09 11:17:21'),
(28, 'Metric Ton', '2017-06-09 11:17:48'),
(29, 'Metric Tons', '2017-06-09 11:18:00'),
(30, 'Ouance', '2017-06-09 11:18:25'),
(31, 'Packets', '2017-06-09 11:18:40'),
(32, 'Pack', '2017-06-09 11:19:13'),
(33, 'Pair', '2017-06-09 11:19:24'),
(34, 'Pairs', '2017-06-09 11:19:41'),
(35, 'Peice', '2017-06-09 11:19:57'),
(36, 'Piece', '2017-06-09 11:20:30'),
(37, 'Pound', '2017-06-09 11:20:46'),
(38, 'Reams', '2017-06-09 11:20:58'),
(39, 'Rolls', '2017-06-09 11:21:09'),
(40, 'Sets', '2017-06-09 11:21:21'),
(41, 'Sheets', '2017-06-09 11:21:31'),
(42, 'Short Ton', '2017-06-09 11:21:48'),
(43, 'Square Feet', '2017-06-09 11:22:07'),
(44, 'Square Meter', '2017-06-09 11:22:22'),
(45, 'Watt', '2017-06-09 11:22:39');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=68 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `phone`, `user_type`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', '03329620292', 'admin', 'RLt5nga0MR7CMAZKBHxa7FoyIZOKL2SO', '$2y$13$3iCj.cwEKX5eNzrP3nt2z.AFurQl9oBqOFBJwvHIotRH4B4uKywRy', NULL, 'sana.ullah@discretelogix.com', 10, 1492075853, 1500631567),
(2, 'CreateSole', '125846958', 'vendor', 'RLt5nga0MR7CMAZKBHxa7FoyIZOKL2SO', '$2y$13$M6oxmWDZFUtxiQWDm9aiyOr3RE80Rym67JeG2kKPAqb86uKmZliiW', NULL, 'vendormail2@gmail.com', 10, 1492174434, 1494583168),
(6, 'AjmalWaqar', '493497394722', 'normal', '7Gf8aVOLxMByT_yGR1KxBSZQYqrAzntk', '$2y$13$j6tLf.Uoy7EPs4PapwVMgu6pkU55dQyrZAEJgSTGwBziJRkd5FStq', NULL, 'fljasdf@gmail.com', 10, 1492426762, 1492426762),
(9, 'AslamCust', 'asdas', 'normal', '563JgNhNGFS3cjNrdQGUyvIsDUm72X-I', '$2y$13$BuVtsbqP.8xSvtxDeYRVeu6jhbHbvtgMpsVrvtCeUEowYUTv1lOW2', NULL, 'sana.ullabh@discretelogix.comb', 10, 1492521200, 1493881633),
(10, 'sanaullah3432', '34322', 'normal', 'XcBYEsu2ldWMuM_PZ_vcgGEne0xVniIT', '$2y$13$7o0JOhWP5.x2t2whPAzmYe.ZkNzT4EGTbJqpdmjBi.9P9UfHaiKBq', NULL, 'sana.ulla343bh@discretelogix.comb2', 10, 1492522696, 1492522696),
(11, 'banjaigaewe', '12312312312321', 'builder', 'ZEicJr7H78La1kYzlqllpqQnlZ7B9mf5', '$2y$13$yoqcoi3RzdTqSfr4Oad8NOfdvZoZiG8Ua8rEVv3qgiO.DK3dhcsne', NULL, 'sana.ulla343bhwew@discretelogix.comb', 10, 1492522811, 1492522811),
(14, 'manufacturer1', 'adsas', 'manufacturer', 'MYGxrZVck8XT62532GOb29pkIC8GnwnL', '$2y$13$45XjP8PWpYPzF4ZwirKii.ikAjS8o547.DrIYpaQ8/09s0PNftWeS', NULL, 'manufacturer@gma1.com', 10, 1492581749, 1492581749),
(15, 'manufacturer2', '493497394722', 'manufacturer', 'KS-CuFvCrNo_jpJODEED_ixoHQlehqwR', '$2y$13$cLzToRDcJbvWDGcsiFXkIOd8NdOmgmY12OnBWZ538/f0uBtE116Lu', NULL, 'manufacturer@gma21.com', 10, 1492582006, 1492582006),
(16, 'builder', '323', 'builder', 'fF9AXcZtaL0Y5581hvzTh9xgw1aOEPuI', '$2y$13$94zX7IxjZUKTP8r4.R0m0OiUN4yF1.wC3iksujNaHA0BBQ/M3aw3e', NULL, 'build@gma21.com', 10, 1492582400, 1492582400),
(26, 'SanaullahVendor', '12312312', 'vendor', 'nBnnjLfb7fTe3E18ecrLFiwdUWv6Zypk', '$2y$13$wDrW0n2GzEHnYh4EoJJNV.wDUnFxwCE8Vn1KvZATd9lFioxzsngXu', NULL, 'sanaullahVendor@gmail.com', 10, 1492697359, 1492697359),
(27, 'SanaullahManufacturer', '234234', 'manufacturer', 'pJXkNptO1GzRcQkXoLd5soXNqoUTo0s9', '$2y$13$UbSaj9YmKZF1mNsGPdiSuOxN9tHsDOPqavzO7NgFIqhgzrpBb5vYO', NULL, 'sanaullahmanufac@gmail.com', 10, 1492697836, 1492697836),
(28, 'SanaullahBuilder', '2222', 'builder', '3mRrQlvlFuWyeyl3Y8NM64COGjRDP_mb', '$2y$13$GfI8GgYTwh9.Vbx5NGrLv.AMAPEIxHSlqVmUfiaUBF0fsJMYoq.fG', NULL, 'sanaullahBuilder@gmail.com', 10, 1492698086, 1492698086),
(29, 'SanaullahBuilder2', '', 'builder', 'WZh3kdBtfOcGwwo1vtiQcGUYqSOkMkBB', '$2y$13$70ZvxDoiMZAHHTlE4RbpYOpPEl821XS5TThf50VHNgEaHcTnk5HxS', NULL, 'sanaullahBuilder@gmail.com2', 10, 1492755067, 1492755067),
(30, 'SanaullahBuilder3', '', 'builder', 'vbXa2JmbECq6Sjm74P-I_rfk_P4KLcEz', '$2y$13$V/CVQxJZMtRpaXg6XxG41elrpVi4GgClZaqvNy881DY/nZFOqPIsa', NULL, 'sana.ulla343bh@discretelogix.combbb', 10, 1492755188, 1492755188),
(31, 'SanaullahVendorbb', '', 'builder', 'oVVX4arDcI36YawfGbBhhi8xjNYOBQLx', '$2y$13$rqgqHScJOAiWYeNovsuC0./1lzEmu9/jiU7UavGdksK9.uQ7dqCI.', NULL, 'sana.ulla343bh@discretelogix.combbbb', 10, 1492755262, 1492755262),
(33, 'NewCustomer', '03329652587', 'normal', 'aWzFrevtVRHglzJs3wGlXyyjeN5VdUIl', '$2y$13$uybDdXNPO3kX/CSTp3QBp..6asCjuJDXsmr2vCj.AWpWh6bWlleLi', NULL, 'newcustomer@discretelogix.combbbb', 10, 1492755663, 1496227791),
(34, 'newcustomer2', '', 'normal', '6ojZrRlawAp5oMF4oQwn0JnhFvr3l6ky', '$2y$13$knx.6UCJ8IQHe43UMQEfGu.UGHiAzgrtYxzNnxGFfwD7G2csZ/ZHK', NULL, 'newcustomer2@discretelogix.combbbb', 10, 1492755827, 1492755827),
(36, 'SanaullahManufacturer4', '', 'manufacturer', 'ViZiCGYk8pbDIGpY9KOsIwmbxR6IU9MK', '$2y$13$SY3EP7Tlpe1Ezu6rf/.eeueIesICJhePaWJ1BtiMuJns04m44EPyS', NULL, 'Manufacturer@discretelogix.combbbb', 10, 1492755960, 1492755960),
(37, 'Builder2232', 'dasdas', 'builder', '0RQF4U_AyRTWHxD_wcJ_9Cy8Iu3Nprft', '$2y$13$6GxD9k8GWzEaAq9tH99g/e6B3C23nzvUHfurF3cprd9kGkJ.ddvJu', NULL, 'Builder2@discretelogix.combbbbm', 10, 1492755988, 1492755988),
(38, 'Architect1', '12345678', 'architect', '0s_lWNo0g2-vTBSWsNjB5Ha0DKl0_j2A', '$2y$13$oxI5CPEZg7OW0mvb5hr/M.bhc/fEjOEZ8dasoZPAQsWuGxaUokhNS', NULL, 'architect1@gmail.com', 10, 1493707100, 1493979749),
(39, 'NileJohn', '+98-669988552244', 'architect', 'cEF8PmH2-l_nFPkkT4o7UbHSyrHNwulP', '$2y$13$egQcGWsitemJ4HbtL.snZOhDBgPXqp0TqZs2mvm/Y4icITpO.p9nK', NULL, 'admingg@famil.com', 10, 1494250205, 1494250205),
(40, 'WanderJacson', '021488855888', 'architect', 'u4HjNVWciu65kJjCa1btTaaSV_LiAcPV', '$2y$13$iQLj6bcZ/5y3KJp7Hk9tZexcRbyHWmKaSP9VJXmpGVBBwVe.92fnO', NULL, 'admin@sdaas.com', 10, 1494311090, 1494311090),
(41, 'Tharawat', '444792848180', 'vendor', 'ZOAQtVSvv_ViUP-QvG0LNIy8KHUGMaYd', '$2y$13$x5T.DofTCS7ZEAD9Ob0xL.etWyLh3DmStLjK/HIj.g4Dpx7YMUUvK', NULL, 'admin@ffggf.com', 10, 1494322509, 1494322509),
(42, 'testvendor', '493497394722', 'vendor', 'rQ-EouuiciqmcerU83HVI9XzN11Edzfv', '$2y$13$bQANtdo5TLaNDjYfmykDi.PGt03NkoJLghngp0VVTku8a.iUx0Fam', NULL, 'testvendor@gmail.com', 10, 1494338221, 1494338221),
(44, 'Test Vendor 1', '090078601', 'vendor', 'F9Nirgpmr4PW9LUXSWcT2bYrHJ7DACiU', '$2y$13$YGm3I0W63nHq5C4lfx3S1u/RlrQtaw0Vs4mumECPJMVXSJbs9PCmm', NULL, 'TestVendor@mailinator.com', 10, 1494401836, 1494401836),
(45, 'Test Vendor', '0900-78601', 'vendor', 'HBFe2v0XqhUbUkG6PCSTEtGUjWDvUZY1', '$2y$13$7fFUCGYJMzf743RtQKU7DO.Au6xTZoAn4kSwTLYDstXyAHcvEvGUa', NULL, 'test@mailinator.com', 10, 1494415476, 1494415476),
(46, 'testvendor2', '493497394722', 'vendor', '1lBooObWhjxw4wc56MwkwQ0jZvq7YP2a', '$2y$13$7Iz4pmrDBFEoheyrrryaru1heXqM3XtFPsolT6e3fGsEhp0bs10uS', NULL, 'testvendor2@gmial.com', 10, 1494514521, 1494514521),
(47, 'Kalim Associates', '0900-78601', 'vendor', 'QzoefDYaaXL6g0ZvdQ8ijQX2INoM4sET', '$2y$13$VKf3nEw7OAPrUSxqXS0kcO8oRES/IFTy4AsbeRDEHR0ajdUJ6M0qG', NULL, 'KA@gmail.com', 10, 1494524707, 1494524707),
(48, 'ArsalanKhalid', '021488855888', 'normal', 'P_ppiLKRph445jjfOlcC2zTofdJZ3JJ4', '$2y$13$0HJ.lNWTsve7R5v029QgkO8X84oq1lVyJ5cZQJvDiNAYg0DOfeipW', NULL, 'admin@asasas.com', 10, 1494853390, 1494853390),
(49, 'WaqasBajwa', '32432423432', 'normal', 'RLt5nga0MR7CMAZKBHxa7FoyIZOKL2SO', '$2y$13$3iCj.cwEKX5eNzrP3nt2z.AFurQl9oBqOFBJwvHIotRH4B4uKywRy', NULL, 'sdfksdsadfsd@gmail.com', 10, 2017, 2017),
(50, 'ZaheerCustomer', '033265987', 'normal', '-W2BsNE7c984O5k5CYzqaElzMZIeJI7a', '$2y$13$cXuVHtDsHDz5hglUZJrSiOFJMPDiDmzSTtoZeaZE20B2xuz5H.PPu', NULL, 'ase@gmail.com', 10, 1495791900, 1495791900),
(51, 'Innovation', '', 'vendor', 'cdmcigikhiyvMO_oQ0-jduvzMWH1W44K', '$2y$13$aiA8OWm7Oqqm5wwM.9o/OOzUBAFt99hYSN/Nv7bCZ9Ruth20pW8MO', NULL, 'admin@gaaa.com', 10, 1496146119, 1496146119),
(52, 'MichelJhon', '8282727272', 'architect', 'qlZdXCgSfAe6J_e5IUHwIQUtxe-9uTR7', '$2y$13$dTzT0ARQZg0IsnIJhmak1uLlOyY3LIf7DBCep9K2IyPoravDA2pvS', NULL, 'adminsss@werwerw.com', 10, 1496150785, 1496150785),
(55, 'Cretesol Islamabad', '0332-5048516', 'vendor', 'gxRO9rOBS051ZXtO1hTczUZqE389P4n_', '$2y$13$7pbzHF27yxW8E.aCPDlIaeXUoWcNA.2tMoZzzqBxpb42MIMqLk8p.', NULL, 'support@cretesol.com', 10, 1496739382, 1496739382),
(56, 'Interwood Mobel (PVT) Ltd.', '12345678', 'vendor', 'mQ3rFbb_Dbs8yAxNNfCXE1o3iNvLkjLp', '$2y$13$nzFvplIhBKlvftkp.Td6IupEuwQIuEUyihWrl.kKGHG8/QwjNouYC', NULL, 'admin@asdfff.com', 10, 1496754080, 1496754080),
(57, 'Grohe', '03126698557', 'manufacturer', '8wA769LgRi2aaTizAew27BWIe1FUbNCH', '$2y$13$MC77tBuRGOUZ6fxV9ByGGepG.pCK9U4KK7uRbKXo8iMeVM6YIUSNa', NULL, 'admin@asdfadsf.com', 10, 1496760613, 1496760613),
(58, 'Saifullah Taps', '12312ou31293192', 'vendor', '2PcZrtHUZ7a7OP2TwD7qNeju5VsgW_Pb', '$2y$13$h./dTuiWad7Htibxxwf87uUCFe60daOneJ1GUtY7xEu2JoJmNfXwK', NULL, 'admin@asdfasfs.com', 10, 1496924960, 1496924960),
(59, 'Aluco bond', '12312312312', 'manufacturer', 'nl6Fg8-Ktf_je3xYuSNUy3X_6znEjnAA', '$2y$13$P8wEcqX6Qnrt5pAz6UrYMeMpuAekbXkct.Wtd.9qT0w7sBpQFQP5y', NULL, 'admin@asdfasdfa.com', 10, 1497505003, 1497505003),
(61, 'farrukh', '', 'normal', 'Xo6ygnMWTknK2BqIcIai52Fh0xSni_nh', '$2y$13$DDsb2cFbX4ls1VAHsM/TV.4xQ4jIHWm5gn3TBLuf0NUoCUAq8/myC', NULL, 'farrukh.jamal91@gmail.com', 10, 1497612778, 1497612778),
(62, 'ali-test', '123123123123', 'normal', 'VyHI0XQG0Bumwro3Hx1KMeqp_gJYrZoh', '$2y$13$YN/C18BFH84tNv15eRNLBuyuVdNhVGWtfywBk/rxNYMHdN8aeJ5Le', NULL, 'admin@admin.com', 10, 1497618021, 1497618021),
(63, 'Ivanka', '1213', 'manufacturer', 'CP2NTf7dnlSJY-YyxYtZ4KKNScwjPvqw', '$2y$13$zRzKuYbV9ht6XfZosXNEtOjS22dJ7CNH9/jadpsxLgry74i.IpzAC', NULL, 'admin11@admin.com', 10, 1497883356, 1497883356),
(64, 'ACL', '123455', 'manufacturer', 'RYHUP8J6YAM7c8fzPmetum3NVKt_DQV3', '$2y$13$N7pdKm3MtcL/g4FFjO8v4uPJZ1A4w.3EO/GhFbwHZah9vzbjQNC4q', NULL, 'admin@acl.asdasd.com', 10, 1497962365, 1497962365),
(65, 'Eglo Group', '123123123123', 'manufacturer', 'JNt2mTXMruiZWzRvObLaqvVkCZlHJxkK', '$2y$13$5Hufoj6cu4w/c3FM.OGrAORngWdy2L8hFQ6Zs6W74AQ6d9yL0CNY.', NULL, 'admin@eglo.admin', 10, 1497964576, 1497964576),
(66, 'Cordula Kafka', '12345', 'manufacturer', 'hOvALVnnYlBSPOLfN0G_jl6FFZj9dxck', '$2y$13$CutCVKxX9nva.ExJhIwD/eP42PIRFEov9VwoyJ04vd05qB0/6vAEO', NULL, 'admin@cordula.kafka', 10, 1497966771, 1497966771),
(67, 'aaa', '', 'normal', 'qjIKqOGynLwbKclXI7ydpOZAoe_cQmVs', '$2y$13$QtxkNP6xW38YlMhg9VaLFOzPkwqX/UthfoBI5QJvg9GDY9jt3EAny', NULL, 'admin@1234.com', 10, 1498197828, 1498197828);

-- --------------------------------------------------------

--
-- Table structure for table `user_addresses`
--

CREATE TABLE IF NOT EXISTS `user_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_adress_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `user_addresses`
--

INSERT INTO `user_addresses` (`id`, `user_id`, `address`, `date_created`) VALUES
(1, 2, 'House no 3, street 4. Islamabad', '0000-00-00 00:00:00'),
(3, 42, 'fgfgf', '0000-00-00 00:00:00'),
(4, 42, 'fgfgfg', '0000-00-00 00:00:00'),
(5, 2, 'Margala town, Scheme 3, how no 555, streat 88.', '0000-00-00 00:00:00'),
(8, 45, 'B Block, Software Technology Park, I-9/3', '0000-00-00 00:00:00'),
(9, 45, 'B Block, Software Technology Park, F-5', '0000-00-00 00:00:00'),
(10, 55, 'C-Block, Liberty, Lahore', '0000-00-00 00:00:00'),
(11, 55, 'Teen Talwar, Karachi', '0000-00-00 00:00:00'),
(12, 38, 'House no 16, street 7 G13, RWP', '0000-00-00 00:00:00'),
(13, 38, 'House no 25, street  46 G13, ISB', '0000-00-00 00:00:00'),
(14, 58, 'asdfas', '0000-00-00 00:00:00'),
(15, 58, '', '0000-00-00 00:00:00'),
(16, 14, 'I-9/3 Islamabad', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_catalogue`
--

CREATE TABLE IF NOT EXISTS `user_catalogue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `catalogue` varchar(100) NOT NULL,
  `catalogue_image` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_catalogue_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `user_catalogue`
--

INSERT INTO `user_catalogue` (`id`, `user_id`, `name`, `catalogue`, `catalogue_image`, `date_created`) VALUES
(1, 14, 'Another catalogue', '14978634515947951b22f530.39317846.pdf', '', '0000-00-00 00:00:00'),
(2, 57, 'catalogue 1', '14978741725947befc076095.33460417.pdf', '', '0000-00-00 00:00:00'),
(3, 57, 'catalogue 2', '14978741725947befc1370a5.99721482.pdf', '', '0000-00-00 00:00:00'),
(7, 63, 'Ivanka concrete factory & designs', '14979478945948def6d85132.56766642.pdf', '', '0000-00-00 00:00:00'),
(8, 63, 'Ivanka Profile', '14979478945948def6e49b04.38168801.pdf', '', '0000-00-00 00:00:00'),
(9, 63, 'Ivanka Profile 02', '14979478945948def6f0e182.58507747.pdf', '', '0000-00-00 00:00:00'),
(10, 64, 'ACL profile', '149796415559491e7b76ad75.08213595.pdf', '', '0000-00-00 00:00:00'),
(11, 64, 'ACL product catalog', '149796415559491e7b82e466.68756639.pdf', '', '0000-00-00 00:00:00'),
(12, 65, 'Eglo Chandliers', '149796520559492295a211b2.61817056.pdf', '', '0000-00-00 00:00:00'),
(13, 66, 'Cordula Kafka Profile', '149796780559492cbd61c1d3.05042055.pdf', '', '0000-00-00 00:00:00'),
(14, 58, '', '1500469896596f5a88b37923.26704867.pdf', '1500469896596f5a88b37e86.66017466.png', '0000-00-00 00:00:00'),
(15, 56, 'Company Profile', '150053207659704d6c070521.56060945.pdf', '150053207659704d6c070901.95734688.jpg', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_collections`
--

CREATE TABLE IF NOT EXISTS `user_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_collections_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `user_collections`
--

INSERT INTO `user_collections` (`id`, `user_id`, `title`, `description`, `date_created`) VALUES
(1, 2, 'Master white collections', 'Interior Collections', '0000-00-00 00:00:00'),
(2, 2, 'Special kitchen collections', 'Indoor Collections', '0000-00-00 00:00:00'),
(3, 47, 'New collection', '', '0000-00-00 00:00:00'),
(4, 47, 'Latest collection', '', '0000-00-00 00:00:00'),
(5, 55, 'Kitchen', 'Complete Kitchen set', '0000-00-00 00:00:00'),
(6, 55, 'Bedroom', 'Complete bedroom set', '0000-00-00 00:00:00'),
(7, 55, 'Bathroom', 'Complete bathroom set', '0000-00-00 00:00:00'),
(8, 56, 'Interesting dining tables', '', '0000-00-00 00:00:00'),
(9, 56, 'Vanity spaces', '', '0000-00-00 00:00:00'),
(10, 56, 'Enticing fancy fountatins', '', '0000-00-00 00:00:00'),
(11, 56, 'Favourite hobs', '', '0000-00-00 00:00:00'),
(12, 58, 'Great photographs', '', '0000-00-00 00:00:00'),
(13, 14, 'manuf Collection', 'manuf Collection Desc', '0000-00-00 00:00:00'),
(14, 63, 'Concrete Collections', '', '0000-00-00 00:00:00'),
(15, 63, 'Interior Cladding', '', '0000-00-00 00:00:00'),
(16, 63, 'Porous facades', '', '0000-00-00 00:00:00'),
(17, 63, 'Louvered facade systems', '', '0000-00-00 00:00:00'),
(18, 63, 'Playful facades', '', '0000-00-00 00:00:00'),
(19, 66, 'Leaves', '', '0000-00-00 00:00:00'),
(20, 66, '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_collections_pictures`
--

CREATE TABLE IF NOT EXISTS `user_collections_pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(45) DEFAULT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `user_collections_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user_collections_id`),
  KEY `fk_user_collections_user_collections_id` (`user_collections_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=140 ;

--
-- Dumping data for table `user_collections_pictures`
--

INSERT INTO `user_collections_pictures` (`id`, `file`, `date_created`, `status`, `user_collections_id`) VALUES
(20, '149665355759351ef5a6b244.66115798.jpg', '2017-06-05 09:05:57', '1', 1),
(21, '149665355959351ef727c6c3.97531967.jpg', '2017-06-05 09:05:59', '1', 1),
(22, '149665356059351ef8367f44.32506844.jpg', '2017-06-05 09:06:00', '1', 1),
(23, '149665356759351effbfea06.32267866.jpg', '2017-06-05 09:06:07', '1', 1),
(24, '149665356859351f00a14420.82804538.jpg', '2017-06-05 09:06:08', '1', 1),
(25, '149665357259351f042bc1d6.64257504.jpg', '2017-06-05 09:06:12', '1', 1),
(26, '149665357859351f0a75b050.18255029.jpg', '2017-06-05 09:06:18', '1', 1),
(27, '149665360159351f21597359.60314599.jpg', '2017-06-05 09:06:41', '1', 1),
(28, '149665370159351f85b074d8.75050273.jpg', '2017-06-05 09:08:21', '1', 2),
(29, '149665370359351f8766d385.83454865.jpg', '2017-06-05 09:08:23', '1', 2),
(30, '149665370759351f8b0c52d3.92678544.jpg', '2017-06-05 09:08:27', '1', 2),
(31, '149665370859351f8c7835f5.02850817.jpg', '2017-06-05 09:08:28', '1', 2),
(32, '149665372659351f9eb7fcc3.20027141.jpg', '2017-06-05 09:08:47', '1', 2),
(33, '149665374259351fae9fed37.90123009.jpg', '2017-06-05 09:09:02', '1', 2),
(34, '149665379559351fe37f0f24.42041752.jpg', '2017-06-05 09:09:55', '1', 2),
(35, '149665379859351fe6cdfca8.06655286.jpg', '2017-06-05 09:09:58', '1', 2),
(36, '149665698259352c56e954f0.66674609.jpg', '2017-06-05 10:03:03', '1', 3),
(37, '149665698459352c58062c27.00550792.jpg', '2017-06-05 10:03:04', '1', 3),
(38, '149665698459352c58b26438.64473220.jpg', '2017-06-05 10:03:04', '1', 3),
(39, '149665699559352c634831f5.60663698.jpg', '2017-06-05 10:03:15', '1', 3),
(40, '149665699759352c65943365.50080586.jpg', '2017-06-05 10:03:17', '1', 3),
(41, '149665699759352c65d5fd59.70627905.jpg', '2017-06-05 10:03:18', '1', 3),
(42, '149665699859352c667ec690.75601643.jpg', '2017-06-05 10:03:18', '1', 3),
(43, '149665699959352c67ea9740.86212244.jpg', '2017-06-05 10:03:20', '1', 3),
(44, '149665778359352f77239d42.20821266.jpg', '2017-06-05 10:16:23', '1', 4),
(45, '149665778359352f77d86e49.92362108.jpg', '2017-06-05 10:16:23', '1', 4),
(46, '149665778459352f780e2bf1.02197944.jpg', '2017-06-05 10:16:24', '1', 4),
(47, '149665778659352f7a238031.66520892.jpg', '2017-06-05 10:16:26', '1', 4),
(48, '149665778659352f7ac30b90.92387736.jpg', '2017-06-05 10:16:26', '1', 4),
(49, '149674714759368c8bf3f618.26426015.jpg', '2017-06-06 11:05:48', '1', 5),
(50, '149674715059368c8ee0b7d9.19879773.jpg', '2017-06-06 11:05:51', '1', 5),
(51, '149674715359368c913f5a88.96150852.jpg', '2017-06-06 11:05:53', '1', 5),
(52, '149674715459368c9297cca9.04924354.jpg', '2017-06-06 11:05:54', '1', 5),
(53, '149674715559368c93633d59.38063824.jpg', '2017-06-06 11:05:55', '1', 5),
(54, '149674715659368c94058b21.18961957.jpg', '2017-06-06 11:05:56', '1', 5),
(55, '149674744959368db91074b7.81058270.jpg', '2017-06-06 11:10:49', '1', 6),
(56, '149674745159368dbbb04599.83687915.jpg', '2017-06-06 11:10:51', '1', 6),
(57, '149674745259368dbcbf7cb3.98185900.jpg', '2017-06-06 11:10:52', '1', 6),
(58, '149674745359368dbda12e24.96550507.jpg', '2017-06-06 11:10:53', '1', 6),
(59, '149674745459368dbe586d14.28410105.jpg', '2017-06-06 11:10:54', '1', 6),
(60, '149674762159368e6581be04.75210633.jpg', '2017-06-06 11:13:41', '1', 7),
(61, '149674762359368e671660d3.04162298.jpg', '2017-06-06 11:13:43', '1', 7),
(62, '149674762359368e67a239e9.12771702.jpg', '2017-06-06 11:13:43', '1', 7),
(63, '149674762459368e68670011.60732115.jpeg', '2017-06-06 11:13:44', '1', 7),
(64, '149674762559368e6905bbe2.42433882.jpg', '2017-06-06 11:13:45', '1', 7),
(65, '14967545555936a97b358e18.22823013.jpg', '2017-06-06 13:09:15', '1', 8),
(66, '14967545555936a97bc13ae7.85422047.jpg', '2017-06-06 13:09:15', '1', 8),
(67, '14967545565936a97c175828.01867120.jpg', '2017-06-06 13:09:16', '1', 8),
(68, '14967545605936a980886147.91637932.jpg', '2017-06-06 13:09:20', '1', 8),
(71, '14967546065936a9ae105a53.81278360.jpg', '2017-06-06 13:10:06', '1', 9),
(72, '14967546095936a9b15897d9.02206494.jpg', '2017-06-06 13:10:09', '1', 9),
(73, '14967546095936a9b1eae8b4.78674987.jpg', '2017-06-06 13:10:10', '1', 9),
(74, '14967546115936a9b3e07ae6.18034672.jpg', '2017-06-06 13:10:12', '1', 9),
(75, '14967546365936a9cc824fa7.07036534.jpg', '2017-06-06 13:10:36', '1', 10),
(76, '14967546365936a9ccbfb658.56717923.jpg', '2017-06-06 13:10:36', '1', 10),
(77, '14967546385936a9ce05b536.67908345.jpg', '2017-06-06 13:10:38', '1', 10),
(78, '14967546425936a9d261d139.53111580.jpg', '2017-06-06 13:10:42', '1', 10),
(79, '14967563715936b093cd7c25.77451805.jpg', '2017-06-06 13:39:32', '1', 11),
(80, '14967563725936b094b46d32.08467761.jpg', '2017-06-06 13:39:33', '1', 11),
(81, '14967563735936b095823ac3.65875589.jpg', '2017-06-06 13:39:33', '1', 11),
(82, '14967563775936b09996f049.18357358.jpg', '2017-06-06 13:39:37', '1', 11),
(83, '14967563785936b09a49b773.05401689.jpg', '2017-06-06 13:39:38', '1', 11),
(84, '14967563795936b09bb41d51.09378917.jpg', '2017-06-06 13:39:40', '1', 11),
(85, '14967563805936b09ca04811.92582736.jpg', '2017-06-06 13:39:42', '1', 11),
(86, '1496925671593945e7816344.95512535.jpg', '2017-06-08 12:41:11', '1', 12),
(87, '1496925671593945e7d5b576.15680333.jpg', '2017-06-08 12:41:11', '1', 12),
(88, '1496925675593945eb24a222.41551969.jpg', '2017-06-08 12:41:15', '1', 12),
(89, '1496925675593945eb58a684.01519418.jpg', '2017-06-08 12:41:15', '1', 12),
(90, '1496925676593945ec567037.48405086.jpg', '2017-06-08 12:41:16', '1', 12),
(91, '1497863612594795bc485002.33197813.jpg', '2017-06-19 09:13:33', '1', 13),
(92, '1497863618594795c23e9fe0.91832098.jpg', '2017-06-19 09:13:39', '1', 13),
(93, '1497863623594795c73b9064.69967062.jpg', '2017-06-19 09:13:44', '1', 13),
(94, '14978842015947e629abfae6.45860932.jpg', '2017-06-19 14:56:41', '1', 14),
(95, '14978842065947e62ecf9956.63812399.jpg', '2017-06-19 14:56:47', '1', 14),
(96, '14978842115947e6334ac703.47969982.jpg', '2017-06-19 14:56:51', '1', 14),
(97, '14978842155947e637de7705.66594327.jpg', '2017-06-19 14:56:56', '1', 14),
(98, '14978842165947e638c2fc56.03303353.jpg', '2017-06-19 14:56:56', '1', 14),
(99, '14978842195947e63b8d01d4.27414913.jpg', '2017-06-19 14:56:59', '1', 14),
(100, '14978842245947e6409172b5.39932353.jpg', '2017-06-19 14:57:04', '1', 14),
(101, '14978842265947e6428ac940.54294768.jpg', '2017-06-19 14:57:06', '1', 14),
(102, '14978842275947e643ab02c6.99705926.jpg', '2017-06-19 14:57:07', '1', 14),
(103, '14978860525947ed6420ffd0.57831767.jpg', '2017-06-19 15:27:32', '1', 15),
(104, '14978860525947ed64baca81.19400841.jpg', '2017-06-19 15:27:32', '1', 15),
(105, '14978860535947ed65701cb9.28115458.jpg', '2017-06-19 15:27:33', '1', 15),
(106, '14978860595947ed6b033a43.07328116.jpg', '2017-06-19 15:27:39', '1', 15),
(107, '14978860625947ed6eea2479.80354718.jpg', '2017-06-19 15:27:43', '1', 15),
(108, '14979543675948f83f16fb50.63801715.jpg', '2017-06-20 10:26:07', '1', 16),
(109, '14979543675948f83fc6e348.03578472.jpg', '2017-06-20 10:26:08', '1', 16),
(110, '14979543685948f8402639d3.42610617.jpg', '2017-06-20 10:26:08', '1', 16),
(111, '14979543715948f8432c2f23.79727005.jpg', '2017-06-20 10:26:11', '1', 16),
(112, '14979543765948f848f28547.66145403.jpg', '2017-06-20 10:26:17', '1', 16),
(113, '14979543775948f849a6b145.12253817.jpg', '2017-06-20 10:26:18', '1', 16),
(114, '14979543785948f84a941f49.61665760.jpg', '2017-06-20 10:26:19', '1', 16),
(116, '14979544575948f899618782.47926149.jpg', '2017-06-20 10:27:37', '1', 17),
(117, '14979544575948f899cbb156.25969143.jpg', '2017-06-20 10:27:38', '1', 17),
(118, '14979544595948f89b1bd091.58999157.jpg', '2017-06-20 10:27:39', '1', 17),
(119, '14979544615948f89d0639a4.93069596.jpg', '2017-06-20 10:27:41', '1', 17),
(120, '14979544645948f8a0428dd3.71374716.jpg', '2017-06-20 10:27:44', '1', 17),
(121, '14979544645948f8a09fae06.02697742.jpg', '2017-06-20 10:27:45', '1', 17),
(122, '14979545855948f919332546.39092794.jpg', '2017-06-20 10:29:45', '1', 18),
(124, '14979545875948f91b1d3af4.03220495.jpg', '2017-06-20 10:29:47', '1', 18),
(125, '14979545885948f91ce1aa82.41118190.jpg', '2017-06-20 10:29:49', '1', 18),
(126, '14979545895948f91d797791.13978061.jpg', '2017-06-20 10:29:49', '1', 18),
(127, '14979545945948f9230069f2.62960775.jpg', '2017-06-20 10:29:55', '1', 18),
(128, '1497967094594929f6d999b4.00992419.jpg', '2017-06-20 13:58:15', '1', 19),
(129, '1497967095594929f7cb3038.83240689.jpg', '2017-06-20 13:58:16', '1', 19),
(130, '1497967096594929f8221e33.43407254.jpg', '2017-06-20 13:58:16', '1', 19),
(131, '1497967100594929fc0c9f35.35023991.jpg', '2017-06-20 13:58:20', '1', 19),
(132, '1497967101594929fd137fa5.82758622.jpg', '2017-06-20 13:58:21', '1', 19),
(133, '149796714459492a28569b54.04976673.jpg', '2017-06-20 13:59:04', '1', 20),
(134, '149796714459492a28e7b287.69466696.jpg', '2017-06-20 13:59:05', '1', 20),
(135, '149796714559492a292a4461.41634378.jpg', '2017-06-20 13:59:05', '1', 20),
(136, '149796714859492a2c9a4526.41543564.jpg', '2017-06-20 13:59:08', '1', 20),
(137, '149796714859492a2cf3da10.49964193.jpg', '2017-06-20 13:59:09', '1', 20),
(138, '149796715059492a2e2ae4c0.84757528.jpg', '2017-06-20 13:59:10', '1', 20),
(139, '149796715059492a2e966ae4.99508626.jpg', '2017-06-20 13:59:11', '1', 20);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_info_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `user_id`, `title`, `description`, `icon`, `date_created`) VALUES
(1, 1, 'myTitle', 'myDescription', '', '2017-04-26 14:23:35'),
(3, 2, 'Registration Number', 'ABN-23446-1', 'Arrow', '2017-04-26 14:58:22'),
(4, 2, 'Identity Number', 'ABN-23446-2', 'Question Mark', '2017-04-26 14:58:22'),
(5, 2, 'S. Security Number', 'ABN-23446-3', 'Arrow', '2017-04-26 14:58:22'),
(6, 2, 'Varification Number', 'ABN-23446-4', 'Question Mark', '2017-04-26 15:06:31'),
(7, 2, 'Information Number', 'ABN-23446-5', 'Arrow', '2017-04-26 15:06:31'),
(8, 38, 'Info Title 2', 'Info Description 2', '', '2017-05-02 11:43:55'),
(9, 38, 'Info Title', 'Info Description', '', '2017-05-02 11:43:55'),
(10, 41, 'Account number:123.1212.12', 'verified', 'Arrow', '0000-00-00 00:00:00'),
(11, 41, 'Leeds Certified', 'Verified', 'Arrow', '0000-00-00 00:00:00'),
(14, 45, 'Registration No.', 'BJG_Info_7824001', '', '0000-00-00 00:00:00'),
(15, 45, 'Identity No.', 'BJG_ID_8238282', '', '0000-00-00 00:00:00'),
(16, 47, 'registration number', '1122-333-444', 'Arrow', '0000-00-00 00:00:00'),
(17, 47, 'validated infomation', 'Not verified', 'Question Mark', '0000-00-00 00:00:00'),
(18, 47, 'ntn number', 'Not verified', 'Question Mark', '0000-00-00 00:00:00'),
(19, 55, 'Registration No.', 'BJG_Ven_021', 'Arrow', '0000-00-00 00:00:00'),
(20, 55, 'Membership Type', 'Premium Vendor', 'Arrow', '0000-00-00 00:00:00'),
(21, 55, 'Company Size', '40-50', 'Arrow', '0000-00-00 00:00:00'),
(22, 55, 'Verification', 'Pending', 'Question Mark', '0000-00-00 00:00:00'),
(23, 56, 'Ntn', '123-234-235', 'Arrow', '0000-00-00 00:00:00'),
(24, 56, 'Authorised retailer of materials', '', 'Arrow', '0000-00-00 00:00:00'),
(25, 58, 'Business ', 'valiated', 'Arrow', '0000-00-00 00:00:00'),
(26, 58, 'VEndorship', 'not verified', 'Question Mark', '0000-00-00 00:00:00'),
(27, 14, 'Identity Number', 'Identity  desc', 'Arrow', '0000-00-00 00:00:00'),
(28, 63, 'Verified Manufacturer ', '', 'Arrow', '0000-00-00 00:00:00'),
(29, 52, 'Registration Number', '112-334-556', 'Arrow', '0000-00-00 00:00:00'),
(30, 52, 'Business Type', 'Sole Propritership', 'Arrow', '0000-00-00 00:00:00'),
(31, 52, 'Active Since', 'November 2004', 'Arrow', '0000-00-00 00:00:00'),
(33, 41, 'Registration number', '12345678', 'Arrow', '0000-00-00 00:00:00'),
(34, 41, 'Business Type', 'Limited company', 'Arrow', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_phone_numbers`
--

CREATE TABLE IF NOT EXISTS `user_phone_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_phonenumber_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `user_phone_numbers`
--

INSERT INTO `user_phone_numbers` (`id`, `user_id`, `phone_number`, `date_created`) VALUES
(1, 2, '+9266599987', '0000-00-00 00:00:00'),
(3, 42, '22222', '0000-00-00 00:00:00'),
(4, 42, '33333', '0000-00-00 00:00:00'),
(5, 2, '+91 5567789', '0000-00-00 00:00:00'),
(8, 45, '0900-78601', '0000-00-00 00:00:00'),
(9, 45, '0900-78602', '0000-00-00 00:00:00'),
(10, 55, '042-2255445', '0000-00-00 00:00:00'),
(11, 55, '021-1155442', '0000-00-00 00:00:00'),
(12, 38, '+92-5568892', '0000-00-00 00:00:00'),
(13, 38, '+92-4457781', '0000-00-00 00:00:00'),
(14, 58, '', '0000-00-00 00:00:00'),
(15, 14, '+92-669336921', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE IF NOT EXISTS `user_profiles` (
  `id` int(11) NOT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `logo` varchar(45) DEFAULT NULL,
  `cover` varchar(45) DEFAULT NULL,
  `cataloguefile` varchar(100) NOT NULL,
  `dealerlistfile` varchar(100) NOT NULL,
  `website` varchar(45) DEFAULT NULL,
  `address` text,
  `about` text,
  `phone` varchar(45) DEFAULT NULL,
  `full_name` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `profile_type` varchar(45) DEFAULT NULL,
  `business_type` varchar(100) NOT NULL,
  `registration_number` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`user_id`),
  KEY `fk_user_profiles_user1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`id`, `date_created`, `status`, `logo`, `cover`, `cataloguefile`, `dealerlistfile`, `website`, `address`, `about`, `phone`, `full_name`, `city`, `country`, `profile_type`, `business_type`, `registration_number`, `user_id`) VALUES
(1, '2017-04-19 08:02:29', '1', '06.jpg', '03.jpg', '', '', 'www.google.com', 'wwwww', 'aaaaaa', 'pppppp', 'fffffff', 'ccccc', 'ccccc', 'Type 2', '', '', 1),
(1, '2017-04-19 08:02:29', '1', '14978665885947a15c97ad89.27619498.jpg', '14978666015947a169764ed2.43382145.jpg', '', '', 'http://www.google.com', 'F-10/3 Islamabad Pakistan.', 'Meet the team responsible for "Building Happiness" in the construction industry: Our close-knit team of Architects, Designers, Material experts and technicians have hundreds of successful projects under their belts', '+92-669988774455', 'Manufacturer 1', 'Islamaabd', 'Pakistan ', 'Type 1', 'Architect Design', '123', 14),
(2, '2017-04-19 08:02:29', '1', '15008943105975d46684d575.55963366.jpg', '15008969205975de985d7cc1.62602992.jpg', '14944035645912c9ec697260.95418831.pdf', '14944035645912c9ec7b25e5.68782712.xlsx', 'http://www.google.com', 'House No.03, street 37,G-13/4', 'Since the nineties, contemporary architecture is being confronted with a contradictory phenomenon. one hand to produce very neutral and anonymous buildings adaptable to different programs. Wanders also designs for architectural projects, such as the Kameha Grand Holidays Halls, Commercial buildings, Villas, Houses, and also give maintenance facilities to the customers. A lots of other services are also offered.', '1234-333-333', 'CreateSole Software Company', 'Islamaabd', 'Pakistan', 'Type 1', 'Architect Design', 'ABN-23446-1', 2),
(2, '2017-04-19 08:06:46', NULL, NULL, NULL, '', '', '22', '22', '22', '2', '222', '222', '222', 'Type 2', '', '', 15),
(3, '2017-04-18 15:13:20', '', NULL, NULL, '', '', 'asdsa', 'asd', 'asds', 'asd', 'adas', 'adsa', 'asdsa', 'Type 1', '', '', 9),
(4, '2017-04-18 15:40:12', '1', 'Discretelogix_400x400.jpg', 'isi_n.jpg', '', '', 'www.google.com', 'adsasd asd2', 'ada sdas2', 'asdasd2', 'asd as2', 'qwqwe', ' dasdasd2', 'Type 2', '', '', 11),
(5, '2017-04-19 08:13:21', NULL, NULL, NULL, '', '', '232', '23', '2323', '2323', '2323', '23232', '2323', 'Type 1', '', '', 16),
(6, '2017-04-19 08:02:29', '1', 'multi-star-img3.jpg', 'banner.png', '', '', 'http://www.google.com', 'House No.03, street 37,G-13/4', 'Since the nineties, contemporary architecture is being confronted with a contradictory phenomenon. one hand to produce very neutral and anonymous buildings adaptable to different programs. Wanders also designs for architectural projects, such as the Kameha Grand Holidays Halls, Commercial buildings, Villas, Houses, and also give maintenance facilities to the customers. A lots of other services are also offerd.', 'asdasd2', 'SDSDS Software Company', 'Islamaabd', 'Pakistan', 'Type 1', '', '', 6),
(10, '2017-04-18 15:38:16', NULL, NULL, NULL, '', '', 'qw2', 'qqwq2', 'q2', 'wq2', 'w2', 'qwqwe2', 'ewqe2', 'Type 1', '', '', 10),
(11, '2017-04-20 16:09:20', '1', '1493895670590b09f6aa9a41.71139815.png', '1493895670590b09f6c2f769.42433640.jpg', '1493895670590b09f6cd2299.38732278.pdf', '1493895670590b09f6d5def3.41710876.xlsx', 'http://www.google.com', 'adsasd asd2', 'ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ada sdas2 lorem ipsum dollar sit amit. ', 'asdasd2', 'asd as2', 'qwqwe', ' dasdasd2', 'Type 1', '', '', 26),
(12, '2017-04-20 16:17:16', '1', 'dxlogo.png', 'maulanamadni.jpg', '', '', '342342', '23423423', '234234', '2423432', '2342342', '234234', '3242342', 'Type 1', '', '', 27),
(13, '2017-04-20 16:21:27', '1', 'error.jpg', 'Live.png', '', '', 'www.google.com', 'adsasd asd2', 'ada sdas2', 'asdasd2', 'asd as2', 'qwqwe', ' dasdasd2', 'Type 1', '', '', 28),
(14, '2017-04-21 08:11:08', NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 29),
(15, '2017-04-21 08:13:08', NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 30),
(16, '2017-04-21 08:14:22', NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 31),
(18, '2017-04-21 08:23:47', NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 34),
(20, '2017-04-21 08:26:00', NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 36),
(21, '2017-04-21 08:26:29', '1', 'test (2).jpg', 'IMG_0580.jpg', '', '', '', '', '', '', '', '', '', 'Type 2', '', '', 37),
(22, '2017-05-02 08:38:20', '1', '14968298815937cfb91feec9.36023253.jpg', '14968298965937cfc88c6196.13374650.jpg', '14937273895908789d0f92e7.52950516.pdf', '14937273895908789d1bf3e0.40062674.xlsx', 'http://www.architect.com', 'House No.03, street 37,G-13/4', 'This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. This is my about lorem ipsum. ', '+926659987', 'ArchiSole Architect Company', 'Islamaabd', 'Pakistan ', 'Type 1', '', '', 38),
(23, '2017-05-08 13:30:05', '1', '15017558705982f9de69a517.39670093.jpg', '15017558795982f9e735a1b5.49822614.jpg', '15017559545982fa3209fb71.27220646.pdf', '15017559545982fa32182bb5.56502279.xlsx', 'http://www.google.com', 'House No.03, street 37,G-13/4', 'This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. This  is about text. ', '+923329658989', 'Nile John', 'Islamaabd', 'Pakistan ', 'Type 1', '', '', 39),
(24, '2017-05-09 06:24:50', '1', '15017560445982fa8ca2e9b1.65198726.jpg', '15017560735982faa9cdd937.93939267.jpg', '15017560855982fab57c0ac4.95387509.pdf', '15017560855982fab58a1e83.06387309.xlsx', 'http://www.architect.com', 'House No.22, street 55,1-9/4', 'this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. this is  about text. ', '+92-669988774455', 'Wander Jacson', 'Islamaabd', 'Pakistan', 'Type 1', '', '', 40),
(25, '2017-05-09 09:35:09', '1', '1494919374591aa8ce298102.04654297.jpg', '1494919358591aa8be9b18f3.38776590.jpg', '149432276959118e51b85ab2.80379330.pdf', '', 'http://www.tharawat-magazine.com', '120 Schwarztorstrasse', 'Subway tile was first used in 1904 when the New York City Subway System opened. Subway tile was chosen for its durability and its smooth surface which was easy to clean. Manufacturers have increased the size and durability of subway tile since its introduction in the early 1900''s. Subway tile has become largely used in houses around the world due to its versatility.', '+91792845580', 'Me Me', 'lahore', 'Pakistan', 'Type 1', '', '', 41),
(26, '2017-05-10 11:24:36', '1', '149664887659350cacb8b876.40409807.jpg', '149664889459350cbe54a824.78211939.jpg', '', '', 'https://www.cretesol.com', 'Block B, Software Technology Park, I-9/3, Islamabad', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '051-2840121', 'Test Vendor Public', 'Islamabad', 'Pakistan', 'Type 2', '', 'BJG_Ven_001', 45),
(27, '2017-05-11 14:55:21', '1', '149451506859147d7c8c9d61.91676926.jpg', '149451509759147d993edd46.66609046.jpg', '149451503159147d577e1995.39698473.pdf', '149451503159147d578a40b6.57394433.xlsx', 'http://www.google.com', 'House No.03, street 37,G-13/4', ' dsfds fsfsdfsdf', 'sd sdfsdf ', ' sdfdsfsdf', 'a asdf', 'sd asdf ads', 'Type 1', ' dfsdafdsaf', ' sdfsdafsd', 46),
(28, '2017-05-11 17:45:07', '1', '1497001400593a6db8153ad5.57270408.jpg', '149665716359352d0bd365d6.08289432.png', '', '', 'https://www.cretesol.com', 'Block B, Software Technology Park, I-9/3, Islamabad', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '0900-78601', 'Farrukh Jamal', 'Islamabad', 'Pakistan', 'Type 1', 'Architect Design', '123', 47),
(29, '2017-05-15 13:03:10', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 48),
(30, '2017-05-19 14:12:38', '', NULL, NULL, '', '', '', '', '', '', 'sdfksdsadfsd', 'Rawalpindi', '', 'Type 1', '', '', 49),
(31, '2017-05-26 09:45:00', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 50),
(32, '2017-05-30 12:08:39', NULL, '1497001419593a6dcbe56335.36057263.jpg', '1497001427593a6dd35f09f7.22834422.jpg', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 51),
(33, '2017-05-30 13:26:26', '1', '1502219552598a0d20f30d72.07817362.jpg', '1502219524598a0d04f25fc9.80097134.jpg', '', '', 'http://www.google.com', 'asdkfa sfdas dflkas jdlfk as dfasd', 'http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39', '100393838', 'Michel Jhon', 'Lahore', 'pakistan', 'Type 1', '', '', 52),
(34, '2017-05-30 13:26:26', '1', '1496151003592d73db378ff2.72449925.jpg', '1496151003592d73db465b94.92447273.jpg', '', '', 'http://www.google.com', 'asdkfa sfdas dflkas jdlfk as dfasd', 'http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39http://projects.discretelogix.org/banjaiga/frontend/web/?r=site/product&id=39', '100393838', '', 'Lhore', 'pakistan', 'Type 1', '', '', 33),
(35, '2017-06-06 08:56:22', '1', '149673992359367053be9f26.40155395.jpg', '149674023359367189e2a827.25265156.jpg', '', '', 'https://www.cretesol.com', 'Block B, Software Technology Park, I-9/3, Islamabad', 'CreteSol (Pvt.) Limited was first established in 2001 as Concrete Solutions and revamped by the name of CreteSol (Pvt.) Ltd. in 2007. The operations of CreteSol belong to ceramic tiles industry which is sub division of construction and material industry in Pakistan. The company is engaged in the wholesale and retail supply of different international brands of ceramic tiles, sanitary ware, granite and marble. CreteSol operates through dedicated sales staff providing services to architects and designers for their commercial and residential projects.\r\nCreteSol has regional offices in all the major urban centers of Pakistan i.e. Islamabad, Rawalpindi, Lahore, Karachi and Peshawar.', '0332-5048516', 'Farrukh Jamal', 'Islamabad', 'Pakistan', 'Type 1', 'Tiles and home accessory merchants', 'BJG_Ven_009', 55),
(36, '2017-06-06 13:01:20', '1', '14967541135936a7c1bc5917.01729656.jpg', '14967541755936a7ff4d2ce6.05228558.jpg', '14967543715936a8c3551535.19415982.pdf', '', 'http://www.interwood.com', 'adasdf', 'INTERWOOD MOBEL is Pakistan’s leading furniture, appliances & accessories brand that covers a wide array of product categories, namely: Office Furniture, Home Furniture, Kids Furniture, Kitchens, Doors, Wardrobes, Flooring and Lifewares.\r\n\r\nWe believe in providing one-window solutions that save you the hassle of building your living space piece by piece. Catering to each and every aspect of our client’s needs, our corporate & domestic ranges both are above par from the industry’s standards.', 'asfas', 'asfas', 'lahore', '', 'Type 1', 'Provate limited', 'N/A', 56),
(37, '2017-06-06 14:50:13', '', '14978723975947b80d92d289.60620182.jpg', '14978724085947b818de7096.85016907.jpg', '14978740465947be7ec882d2.84628770.pdf', '14978740465947be7ed81766.08088525.xlsx', '', '', '', '', '', '', '', '', '', '', 57),
(38, '2017-06-08 12:29:20', '1', '149692507359394391c31650.58760554.jpg', '1496925110593943b6a65fc0.19519475.jpg', '14969254515939450b4c75b6.75377560.pdf', '', 'http://wwww.asdfasdfas.com', 'asdfasdf', 'asdfasdfasdf', '131233123', 'Waqas Ahmad', 'lahore', 'Pakistan', 'Type 1', '', '123423-224-44-', 58),
(39, '2017-06-15 05:36:43', '1', NULL, '149750526659421df2ba0870.81464502.jpg', '', '', 'http://www.asdfasd.com', 'adfasdf', 'Sefar is the leading manufacturer of precision fabrics from monofilaments for the screen printing and filtration markets. Sefar products are used in a wide variety of industries, reaching from electronics, graphics, medical, automotive, food and pharmaceutical applications to aerospace, mining & refining and architecture. With its profound understanding of the applications Sefar helps its customers to achieve optimum results in their industrial processes.', '+232232 232342 ', 'Sefar', 'Milan', 'Italy', 'Type 1', '', '', 59),
(40, '2017-06-16 11:32:58', NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 61),
(41, '2017-06-16 13:00:21', '', NULL, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 62),
(42, '2017-06-19 14:42:36', '1', '14978837175947e4459c3ef3.40497215.jpeg', '14978835145947e37a7f8a77.87232756.jpg', '14978838025947e49ada9e07.02766891.pdf', '', 'http://ivankaconcrete.com/en', 'H–2000 Szentendre, Kalaszi ut 3, Hungry', 'IVANKA company group has a 360-degree approach to its projects, giving complete, full circle services to its Clients. Beside the serial production and custom manufacturing of high-quality concrete products, IVANKA provides high service in architecture, design and engineering, research and development, technological innovation, packaging, worldwide shipping, project management and installation.  IVANKA gives full support to the architect and designer community, from the first detailed studying of each project - in terms of feasibility and pricing – to the working out of the best possible solution for the physical realization of even the most challenging creations of design.', '+36 20 398 55 11', 'IVANKA company group', 'Szentendre', 'Hungry', 'Type 1', '', '', 63),
(43, '2017-06-20 12:39:25', '1', '14979626515949189b6b5948.92098217.jpg', '1497962747594918fb98e161.64656014.jpg', '149796280259491932f14655.94907027.pdf', '', 'http://aclweb.pt/en/company', 'RUA PADRE DOMINGOS JOAQUIM PEREIRA Nº1284 - LOURO - Ap. 163 - E.C. Famalicão 4761-926 V.N. Famalicão Portugal', 'Founded in 1975, our growth is based on constant innovation combined with the excellenceof our products. Cimenteira do Louro is currently prepared to face the challenges determined by the new century, constantly pursuing the continuous efficiency in responding to client requests. We believe in what we do! That is why, since the beginning, Cimenteira do Louro has always invested in forms of producing more and better, a continuous evolution which contributes to our Clients’ growth.  Combining aesthetics, quality and the reliability of our products results in a unique alliance between technical know how and innovative and quality design, creating a harmony of renowned efficiency: the factor which differentiates us on the market. Our proactiveness, quality and effectiveness have allowed us to work on large infrastructure projects in Portugal, such as highways, roads and a number of different pavements. It is very likely that on your way to work, you will already have come across some of our work.', '+351 252 301 900', '', 'FAMALICÃO', 'Portugal', 'Type 1', 'Registered COmpany', '110-001-004', 64),
(44, '2017-06-20 13:16:16', '1', '1497964707594920a33510c5.39416646.jpg', NULL, '', '', 'http://www.eglo.com/international', 'EGLO Leuchten GmbH  Heiligkreuz 22  A-6136 Pill', 'Wall concrete tiles for exterior and interior.  Given the characteristics of aggregates and their photographic reproduction, there may be slight variations in particle size and tone.', '+43 5242 6996 0', 'Eglo Lights International', 'Heiligkreuz', 'Austria', 'Type 1', 'Registered Company', '110-001-005', 65),
(45, '2017-06-20 13:52:52', '', '14979669155949294382ed56.53546919.jpg', '1497966965594929755db249.60338087.jpg', '', '', 'http://cordulakafka.de/en/work/', 'Cordula Kafka—Light & Porcelain Heidelberger Strasse 65/66 D–12435 Berlin T  +49 (0)30 20 06 95 01 M +49 (0)173 2 60 60 49 kontakt@cordulakafka.de', 'Porcelain in combination with light forms the foundation of the work of cordula kafka – light & porcelain. In Berlin studio ideas in porcelain arises, the implementation is worked out and finally the pieces are made by hand with traditional and also with newly developed porcelain techniques. In collaboration with German lamp manufactories and light technicians formally minimal and technically demanding products are developed with porcelain as the main protagonist, resulting in the highest quality, modern lighting solutions. Since fifteen years small editions and unique pieces are formed for private residences, hotels and restaurants for clients in Germany, Austria, Swiss, Belgium, Italy, Luxembourg, GB, Marokko, USA und Hong Kong.', '+49 (0)30 20 06 95 01', 'Cordula Kafka', 'Berlin', 'Germany', 'Type 1', '', '', 66),
(46, '2017-06-23 06:03:48', NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 67);

-- --------------------------------------------------------

--
-- Table structure for table `user_shopping_list`
--

CREATE TABLE IF NOT EXISTS `user_shopping_list` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `date_created` varchar(45) DEFAULT NULL,
  `date_updated` varchar(45) NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `is_current` int(11) DEFAULT '0',
  PRIMARY KEY (`id`,`user_id`),
  KEY `fk_user_shopping_list_user1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_shopping_list`
--

INSERT INTO `user_shopping_list` (`id`, `name`, `date_created`, `date_updated`, `status`, `user_id`, `is_current`) VALUES
(1, 'Indoor item', '2017-06-13 11:33:14', '', '1', 33, 0),
(3, 'Luxury Items', '2017-06-15 13:04:06', '', '1', 33, 0),
(4, 'new tiles', '2017-06-16 13:01:47', '', '1', 62, 0),
(5, 'My Shoping List 557', '2017-06-16 13:06:26', '', '1', 62, 0),
(6, 'My Shoping List 211', '2017-06-16 13:09:38', '', '1', 62, 0),
(7, 'My Shoping List 830', '2017-06-16 13:10:28', '', '1', 62, 0),
(8, 'My Shoping List 393', '2017-06-16 13:11:36', '', '1', 62, 0),
(9, 'facade items', '2017-06-16 13:49:26', '', '1', 62, 0),
(10, 'My Shoping List 941', '2017-06-16 13:51:11', '', '1', 62, 0),
(11, 'My Shoping List 360', '2017-06-19 05:56:43', '', '1', 62, 0),
(12, 'My Shoping List 1819', '2017-06-19 16:10:51', '', '1', 62, 0),
(13, 'new list 02', '2017-06-20 06:37:29', '', '1', 62, 0),
(14, 'Outdoor Items', '2017-06-21 07:51:12', '', '1', 33, 0),
(15, 'Furniture', '2017-06-21 07:52:06', '', '1', 33, 0),
(16, 'Interior', '2017-06-21 07:54:32', '', '1', 33, 0),
(17, 'My Shoping List', '2017-06-21 11:11:11', '', '1', 62, 0),
(18, 'My Shoping List', '2017-06-23 06:04:24', '', '0', 67, 0),
(19, 'My kitchen-01', '2017-07-01 10:47:47', '2017-08-09 00:24:29', '', 67, 0),
(20, 'New kitchens for my home', '2017-07-02 09:15:33', '', '', 67, 0),
(21, 'My Shoping List 281', '2017-07-04 13:45:47', '', '0', 67, 0),
(22, 'My Shoping List 1601', '2017-07-04 13:45:54', '2017-08-01 13:01:49', '0', 67, 0),
(23, 'Laterst list-001', '2017-07-04 13:45:58', '2017-07-28 01:21:49', '1', 67, 0),
(24, 'My Shoping List', '2017-07-05 10:04:43', '2017-07-19 18:47:56', '0', 33, 0),
(25, 'My Shoping List 1652', '2017-07-05 10:04:58', '', '0', 33, 0),
(26, 'My Shoping List', '2017-07-05 12:51:21', '', '0', 67, 1),
(27, 'test my list-01', '2017-07-05 12:52:05', '2017-07-07 20:07:05', '0', 67, 0),
(28, 'My Shoping List', '2017-07-06 13:26:21', '2017-07-07 19:59:06', '4', 33, 0),
(29, 'My Shoping List', '2017-07-10 14:44:19', '', '0', 33, 0),
(30, 'My Shoping List', '2017-07-11 17:21:50', '2017-07-11 17:22:26', '0', 67, 0),
(31, 'My Shoping List', '2017-07-18 23:13:25', '2017-07-19 18:46:33', '0', 67, 0),
(32, 'ali test', '2017-07-18 23:15:56', '', '', 62, 0),
(33, 'my flooring', '2017-07-19 18:49:36', '2017-07-19 18:53:15', '0', 67, 0),
(34, 'new kitchen', '2017-07-19 18:54:01', '2017-07-28 00:34:53', '0', 9, 0),
(35, 'New Shopping list', '2017-08-07 11:54:34', '', '0', 33, 0),
(36, 'My Shoping List 1327', '2017-08-07 11:57:03', '', '0', 33, 0),
(37, 'My Shoping List 1021', '2017-08-07 13:41:46', '', '0', 67, 0),
(38, 'My Shoping List 763', '2017-08-07 13:42:08', '', '0', 67, 0),
(39, 'My Shoping List', '2017-08-08 14:57:54', '2017-08-09 00:49:57', '1', 33, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_team`
--

CREATE TABLE IF NOT EXISTS `user_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_team_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `user_team`
--

INSERT INTO `user_team` (`id`, `user_id`, `name`, `designation`, `picture`, `date_created`) VALUES
(10, 38, 'Archi member 1', '1 Designation', '149370739359082a81327397.17790826.png', '2017-05-02 11:43:13'),
(11, 38, 'Archi member 2', '2 Designation', '149370739359082a814457d2.59445861.png', '2017-05-02 11:43:13'),
(12, 26, 'sdfsd', 'sdfsd', '149425061459107476c6df94.98408951.jpg', '0000-00-00 00:00:00'),
(13, 26, 'sdfsdf', 'sdfs', '1494250632591074887cbcf2.22512764.jpg', '0000-00-00 00:00:00'),
(15, 2, 'Rangzar khan', 'CEO', '14943325885911b4ac6607b2.88381670.png', '0000-00-00 00:00:00'),
(16, 2, 'Aqeel khan', 'Manager', '14955272685923ef6438d840.91584796.png', '0000-00-00 00:00:00'),
(17, 42, 'sdad', 'rere', '14943383635911cb3b21ebd3.27084246.png', '0000-00-00 00:00:00'),
(18, 44, 'F', 'J', '14944144505912f472f35259.06026868.jpg', '0000-00-00 00:00:00'),
(21, 2, 'sadsa', 'asdas', '14944161515912fb17886263.44260354.png', '0000-00-00 00:00:00'),
(22, 45, 'Amir', 'Team lead', '1494920960591aaf009a8008.33700810.jpg', '0000-00-00 00:00:00'),
(23, 45, 'Farukh', 'Team lead', '1494920929591aaee1302b26.79377453.jpg', '0000-00-00 00:00:00'),
(25, 2, 'sfsdf', 'sdfs', '14963310565930333081f149.88742695.jpeg', '0000-00-00 00:00:00'),
(26, 47, '', '', '149665728159352d8118fc64.21275141.png', '0000-00-00 00:00:00'),
(27, 55, 'Akhter Shabir', 'CEO', '1496742007593678779ebe84.60090500.JPG', '0000-00-00 00:00:00'),
(28, 55, 'Tahir Hussain', 'CMO', '149674200759367877af31c3.64315723.JPG', '0000-00-00 00:00:00'),
(29, 56, 'Bashir', 'Shakir', '14967543715936a8c35f03c5.16745605.jpeg', '0000-00-00 00:00:00'),
(32, 38, 'czxc', 'zxczxc Designation', '14968301625937d0d2c6e364.87840598.jpg', '0000-00-00 00:00:00'),
(33, 58, '', '', '', '0000-00-00 00:00:00'),
(34, 56, 'Shafiq', 'Qazi', '150053187359704ca1494b60.13930763.png', '0000-00-00 00:00:00'),
(35, 52, 'Michael Korr', 'Chief Designer', '1502219424598a0ca02ad839.06186667.png', '0000-00-00 00:00:00'),
(36, 41, 'Natasha Khan', 'CEO', '1502221518598a14ce62de31.03006489.png', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_testimonials`
--

CREATE TABLE IF NOT EXISTS `user_testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_from` int(11) NOT NULL,
  `description` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_user_testimonials_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user_testimonials`
--

INSERT INTO `user_testimonials` (`id`, `user_id`, `user_from`, `description`, `date_created`) VALUES
(1, 55, 9, 'The solid wood frame and clean-cut geometric lines are complemented by the fluid line of the backres', '2017-06-06 09:41:02'),
(2, 55, 33, 'The solid wood frame and clean-cut geometric lines are complemented by the fluid line.', '2017-06-06 09:42:20'),
(3, 55, 50, 'The solid wood frame and clean-cut geometric lines are complemented by the fluid line 2', '2017-06-06 09:42:34'),
(4, 38, 9, 'The solid wood frame and clean-cut geometric lines are complemented by the fluid line of the backrests, ensuring a comfortable and refined seat.', '2017-06-08 05:52:47'),
(5, 38, 33, 'The solid wood frame and clean-cut geometric lines are complemented by the fluid line of the backrests, ensuring a comfortable and refined seat.', '2017-06-08 05:53:10'),
(6, 38, 50, 'The solid wood frame and clean-cut geometric lines are complemented by the fluid line of the backrests, ensuring a comfortable and refined seat.', '2017-06-08 05:53:41'),
(7, 14, 10, 'Hi this is testimonial', '2017-06-19 10:11:41');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE IF NOT EXISTS `vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `vendor_type` int(11) NOT NULL DEFAULT '0' COMMENT '0=gold, 1=regular',
  PRIMARY KEY (`id`,`user_id`),
  KEY `fk_vendors_user1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `user_id`, `vendor_type`) VALUES
(1, 2, 0),
(16, 26, 0),
(19, 41, 0),
(23, 45, 0),
(24, 46, 0),
(25, 47, 0),
(26, 51, 0),
(27, 55, 0),
(28, 56, 0),
(29, 58, 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `architects`
--
ALTER TABLE `architects`
  ADD CONSTRAINT `fk_architects_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `architect_trusted_vendors`
--
ALTER TABLE `architect_trusted_vendors`
  ADD CONSTRAINT `fk_architect_vendors_products1` FOREIGN KEY (`architects_id`) REFERENCES `architects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_architect_vendors_vendors1` FOREIGN KEY (`vendors_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `builders`
--
ALTER TABLE `builders`
  ADD CONSTRAINT `fk_builders_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `leeds`
--
ALTER TABLE `leeds`
  ADD CONSTRAINT `fk_leeds_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `leed_assignments`
--
ALTER TABLE `leed_assignments`
  ADD CONSTRAINT `fk_leed_assignments_leeds1` FOREIGN KEY (`leeds_id`) REFERENCES `leeds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `manufacturers`
--
ALTER TABLE `manufacturers`
  ADD CONSTRAINT `fk_manufacturers_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_catalogue`
--
ALTER TABLE `product_catalogue`
  ADD CONSTRAINT `fk_product_catalogue_product1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD CONSTRAINT `fk_product_categories_categories1` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_product_categories_products1` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_manufacturers`
--
ALTER TABLE `product_manufacturers`
  ADD CONSTRAINT `fk_product_manufacturers_manufacturers1` FOREIGN KEY (`manufacturers_id`) REFERENCES `manufacturers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_product_manufacturers_products1` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_pictures`
--
ALTER TABLE `product_pictures`
  ADD CONSTRAINT `fk_product_pictures_products1` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_ratings`
--
ALTER TABLE `product_ratings`
  ADD CONSTRAINT `fk_product_ratings_products1` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_vendors`
--
ALTER TABLE `product_vendors`
  ADD CONSTRAINT `fk_product_vendors_products1` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_product_vendors_vendors1` FOREIGN KEY (`vendors_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile_ratings`
--
ALTER TABLE `profile_ratings`
  ADD CONSTRAINT `fk_profile_ratings_user_profiles1` FOREIGN KEY (`user_profiles_id`) REFERENCES `user_profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `fk_projects_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_assignments`
--
ALTER TABLE `project_assignments`
  ADD CONSTRAINT `fk_project_assignments_projects1` FOREIGN KEY (`projects_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_pictures`
--
ALTER TABLE `project_pictures`
  ADD CONSTRAINT `fk_project_pictures_projects1` FOREIGN KEY (`projects_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopping_list_items`
--
ALTER TABLE `shopping_list_items`
  ADD CONSTRAINT `fk_shopping_list_items_products1` FOREIGN KEY (`products_id`, `products_product_categories_id`) REFERENCES `products` (`id`, `product_categories_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_shopping_list_items_user_shopping_list1` FOREIGN KEY (`user_shopping_list_id`, `user_shopping_list_user_id`) REFERENCES `user_shopping_list` (`id`, `user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopping_list_items_info`
--
ALTER TABLE `shopping_list_items_info`
  ADD CONSTRAINT `fk_shopping_list_item_id` FOREIGN KEY (`shopping_list_item_id`) REFERENCES `shopping_list_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD CONSTRAINT `fk_user_adress_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_catalogue`
--
ALTER TABLE `user_catalogue`
  ADD CONSTRAINT `fk_user_catalogue_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_collections`
--
ALTER TABLE `user_collections`
  ADD CONSTRAINT `fk_user_collections_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_collections_pictures`
--
ALTER TABLE `user_collections_pictures`
  ADD CONSTRAINT `fk_user_collections_user_collections_id` FOREIGN KEY (`user_collections_id`) REFERENCES `user_collections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_info`
--
ALTER TABLE `user_info`
  ADD CONSTRAINT `fk_user_info_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_phone_numbers`
--
ALTER TABLE `user_phone_numbers`
  ADD CONSTRAINT `fk_user_phonenumber_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `fk_user_profiles_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_shopping_list`
--
ALTER TABLE `user_shopping_list`
  ADD CONSTRAINT `fk_user_shopping_list_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_team`
--
ALTER TABLE `user_team`
  ADD CONSTRAINT `fk_user_team_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_testimonials`
--
ALTER TABLE `user_testimonials`
  ADD CONSTRAINT `fk_user_user_testimonials_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vendors`
--
ALTER TABLE `vendors`
  ADD CONSTRAINT `fk_vendors_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
